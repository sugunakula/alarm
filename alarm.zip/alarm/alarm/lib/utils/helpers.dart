import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/alarm_model.dart';
import 'constants.dart';

class AppHelpers {
  // Time formatting helpers
  static String formatTime(DateTime dateTime, {bool use24Hour = false}) {
    final format = use24Hour ? AppConstants.timeFormat24 : AppConstants.timeFormat12;
    return DateFormat(format).format(dateTime);
  }

  static String formatDate(DateTime dateTime) {
    return DateFormat(AppConstants.dateFormat).format(dateTime);
  }

  static String formatFullDate(DateTime dateTime) {
    return DateFormat(AppConstants.fullDateFormat).format(dateTime);
  }

  static String formatTimeUntil(DateTime futureTime) {
    final now = DateTime.now();
    final difference = futureTime.difference(now);
    
    if (difference.isNegative) {
      return 'Past due';
    }
    
    if (difference.inDays > 0) {
      return 'in ${difference.inDays} day${difference.inDays > 1 ? 's' : ''}';
    } else if (difference.inHours > 0) {
      return 'in ${difference.inHours} hour${difference.inHours > 1 ? 's' : ''}';
    } else if (difference.inMinutes > 0) {
      return 'in ${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''}';
    } else {
      return 'very soon';
    }
  }

  static String formatDuration(Duration duration) {
    if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}m';
    } else if (duration.inMinutes > 0) {
      return '${duration.inMinutes}m ${duration.inSeconds % 60}s';
    } else {
      return '${duration.inSeconds}s';
    }
  }

  // Alarm helpers
  static String getRepeatText(RepeatOption repeatOption) {
    switch (repeatOption) {
      case RepeatOption.never:
        return 'Once';
      case RepeatOption.daily:
        return 'Daily';
      case RepeatOption.weekdays:
        return 'Weekdays';
      case RepeatOption.weekends:
        return 'Weekends';
      case RepeatOption.custom:
        return 'Custom';
    }
  }

  static String getCustomDaysText(List<int> customDays) {
    if (customDays.isEmpty) return 'No days selected';
    
    customDays.sort();
    final dayNames = customDays.map((day) => AppConstants.weekdayShort[day - 1]).toList();
    
    if (dayNames.length <= 3) {
      return dayNames.join(', ');
    } else {
      return '${dayNames.take(2).join(', ')} +${dayNames.length - 2} more';
    }
  }

  static bool isAlarmActiveToday(AlarmModel alarm) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final alarmDate = DateTime(alarm.dateTime.year, alarm.dateTime.month, alarm.dateTime.day);
    
    if (alarmDate.isBefore(today)) {
      return false;
    }
    
    switch (alarm.repeatOption) {
      case RepeatOption.never:
        return alarmDate == today;
      case RepeatOption.daily:
        return true;
      case RepeatOption.weekdays:
        final weekday = now.weekday;
        return weekday >= 1 && weekday <= 5; // Monday to Friday
      case RepeatOption.weekends:
        final weekday = now.weekday;
        return weekday == 6 || weekday == 7; // Saturday and Sunday
      case RepeatOption.custom:
        return alarm.customDays.contains(now.weekday);
    }
  }

  // Game helpers
  static String getGameName(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return 'Math';
      case GameType.findTheBall:
        return 'Find Ball';
      case GameType.puzzleSolve:
        return 'Puzzle';
      case GameType.colorMatchBlitz:
        return 'Color Match';
      case GameType.memoryFlip:
        return 'Memory';
    }
  }

  static IconData getGameIcon(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return Icons.calculate;
      case GameType.findTheBall:
        return Icons.sports_baseball;
      case GameType.puzzleSolve:
        return Icons.extension;
      case GameType.colorMatchBlitz:
        return Icons.palette;
      case GameType.memoryFlip:
        return Icons.psychology;
    }
  }

  static Color getGameColor(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return const Color(0xFF4CAF50);
      case GameType.findTheBall:
        return const Color(0xFF9C27B0);
      case GameType.puzzleSolve:
        return const Color(0xFFFF5722);
      case GameType.colorMatchBlitz:
        return const Color(0xFFE91E63);
      case GameType.memoryFlip:
        return const Color(0xFF00BCD4);
    }
  }

  // Score helpers
  static String getScoreGrade(double successRate) {
    if (successRate >= 0.9) return 'S';
    if (successRate >= 0.8) return 'A';
    if (successRate >= 0.7) return 'B';
    if (successRate >= 0.6) return 'C';
    if (successRate >= 0.5) return 'D';
    return 'F';
  }

  static Color getScoreColor(double successRate) {
    if (successRate >= 0.8) return Colors.green;
    if (successRate >= 0.6) return Colors.orange;
    return Colors.red;
  }

  // Validation helpers
  static bool isValidAlarmLabel(String label) {
    return label.trim().length <= AppConstants.maxAlarmLabelLength;
  }

  static bool isValidTimeLimit(int seconds) {
    return seconds >= AppConstants.minGameTimeLimit && 
           seconds <= AppConstants.maxGameTimeLimit;
  }

  static String? validateAlarmLabel(String? value) {
    if (value == null || value.trim().isEmpty) {
      return null; // Label is optional
    }
    
    if (value.trim().length > AppConstants.maxAlarmLabelLength) {
      return 'Label must be ${AppConstants.maxAlarmLabelLength} characters or less';
    }
    
    return null;
  }

  // UI helpers
  static void showSnackBar(BuildContext context, String message, {Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: backgroundColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  static void showErrorSnackBar(BuildContext context, String message) {
    showSnackBar(context, message, backgroundColor: Colors.red[600]);
  }

  static void showSuccessSnackBar(BuildContext context, String message) {
    showSnackBar(context, message, backgroundColor: Colors.green[600]);
  }

  static Future<bool?> showConfirmDialog(
    BuildContext context, {
    required String title,
    required String content,
    String confirmText = 'Confirm',
    String cancelText = 'Cancel',
  }) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(cancelText),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(confirmText),
          ),
        ],
      ),
    );
  }

  // Calculation helpers
  static double calculateSuccessRate(int completed, int total) {
    if (total == 0) return 0.0;
    return completed / total;
  }

  static int calculateStreakBonus(int streak) {
    if (streak >= 10) return 30;
    if (streak >= 5) return 15;
    if (streak >= 3) return 5;
    return 0;
  }

  static int calculateTimeBonus(Duration remaining, Duration total) {
    if (total.inSeconds == 0) return 0;
    final ratio = remaining.inSeconds / total.inSeconds;
    return (ratio * 20).round();
  }

  // Device helpers
  static bool isTablet(BuildContext context) {
    final data = MediaQuery.of(context);
    return data.size.shortestSide >= 600;
  }

  static bool isDarkMode(BuildContext context) {
    return Theme.of(context).brightness == Brightness.dark;
  }

  static double getScreenWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  static double getScreenHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }

  // Utility functions
  static String capitalize(String text) {
    if (text.isEmpty) return text;
    return text[0].toUpperCase() + text.substring(1);
  }

  static String truncateText(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  static List<T> removeDuplicates<T>(List<T> list) {
    return list.toSet().toList();
  }

  static T? findInList<T>(List<T> list, bool Function(T) test) {
    try {
      return list.firstWhere(test);
    } catch (e) {
      return null;
    }
  }

  // Debug helpers
  static void debugLog(String message) {
    debugPrint('[NoSnooz] $message');
  }

  static void debugLogError(String error, [StackTrace? stackTrace]) {
    debugPrint('[NoSnooz ERROR] $error');
    if (stackTrace != null) {
      debugPrint('[NoSnooz STACK] $stackTrace');
    }
  }
}
