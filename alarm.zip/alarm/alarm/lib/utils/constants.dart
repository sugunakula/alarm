class AppConstants {
  // App Information
  static const String appName = 'NoSnooz';
  static const String appTagline = 'Wake up with purpose';
  static const String appVersion = '1.0.0';

  // Subscription Information
  static const String monthlyPlanId = 'nosnooz_monthly';
  static const String yearlyPlanId = 'nosnooz_yearly';
  static const double monthlyPrice = 4.99;
  static const double yearlyPrice = 29.99;
  static const int trialDays = 7;

  // Game Configuration
  static const int maxFreeAlarms = 5;
  static const int defaultGameTimeLimit = 60; // seconds
  static const int maxGameAttempts = 3;
  static const int minPasswordLength = 6;

  // Animation Durations
  static const int splashDurationMs = 2500;
  static const int shortAnimationMs = 300;
  static const int longAnimationMs = 1000;

  // Default Alarm Settings
  static const String defaultAlarmLabel = 'Alarm';
  static const bool defaultVibration = true;
  static const bool defaultScreenLight = true;
  static const double defaultAlarmVolume = 0.8;

  // Game Scoring
  static const int baseScoreEasy = 10;
  static const int baseScoreMedium = 20;
  static const int baseScoreHard = 30;
  static const int streakBonus = 10;
  static const int perfectRoundBonus = 50;

  // Error Messages
  static const String networkError = 'Please check your internet connection';
  static const String genericError = 'Something went wrong. Please try again.';
  static const String alarmLimitError = 'Free users can create up to 5 alarms only';
  static const String premiumRequiredError = 'This feature requires a premium subscription';

  // Success Messages
  static const String alarmCreatedSuccess = 'Alarm created successfully';
  static const String alarmUpdatedSuccess = 'Alarm updated successfully';
  static const String alarmDeletedSuccess = 'Alarm deleted successfully';
  static const String gameCompletedSuccess = 'Game completed! Alarm dismissed.';

  // URLs (for future use)
  static const String privacyPolicyUrl = 'https://nosnooz.app/privacy';
  static const String termsOfServiceUrl = 'https://nosnooz.app/terms';
  static const String supportUrl = 'https://nosnooz.app/support';
  static const String websiteUrl = 'https://nosnooz.app';

  // Local Storage Keys
  static const String alarmsKey = 'alarms';
  static const String gameStatsKey = 'game_stats';
  static const String subscriptionKey = 'user_subscription';
  static const String settingsKey = 'app_settings';
  static const String onboardingKey = 'onboarding_completed';

  // Asset Paths
  static const String logoPath = 'assets/images/logo.svg';
  static const String defaultAlarmSound = 'assets/sounds/default_alarm.mp3';
  static const String successSound = 'assets/sounds/success.mp3';
  static const String failureSound = 'assets/sounds/failure.mp3';
  static const String buttonClickSound = 'assets/sounds/click.mp3';

  // Notification IDs
  static const int alarmNotificationId = 1000;
  static const int reminderNotificationId = 2000;

  // Premium Features List
  static const List<String> premiumFeatures = [
    'All 5 mini-games unlocked',
    'Unlimited alarms',
    'Custom alarm sounds',
    'Advanced customization',
    'Priority customer support',
    'Ad-free experience',
    'Cloud sync (coming soon)',
    'Custom themes (coming soon)',
  ];

  // Free Features List
  static const List<String> freeFeatures = [
    'Math equation game',
    'Up to 5 alarms',
    'Basic customization',
    'Standard support',
  ];

  // Weekdays
  static const List<String> weekdayNames = [
    'Monday',
    'Tuesday', 
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  static const List<String> weekdayShort = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];

  // Time Formats
  static const String timeFormat12 = 'h:mm a';
  static const String timeFormat24 = 'HH:mm';
  static const String dateFormat = 'EEEE, MMMM d';
  static const String fullDateFormat = 'EEEE, MMMM d, yyyy';

  // Game Instructions
  static const Map<String, String> gameInstructions = {
    'math': 'Solve arithmetic problems quickly and accurately. The difficulty adapts based on your performance.',
    'findball': 'Watch carefully as the cups shuffle and keep track of which cup hides the ball.',
    'puzzle': 'Slide the puzzle pieces to complete the image using the empty space strategically.',
    'colormatch': 'Match the colors as quickly as possible! Tap the color that matches the target.',
    'memory': 'Flip cards to find matching pairs. Remember where each card is located.',
  };

  // Validation Rules
  static const int maxAlarmLabelLength = 50;
  static const int minGameTimeLimit = 30;
  static const int maxGameTimeLimit = 300;
  static const int maxStreakCount = 999;

  // Performance Settings
  static const int maxCachedGameStats = 100;
  static const int maxRecentAlarms = 20;
  static const Duration cacheValidityDuration = Duration(hours: 24);

  // Accessibility
  static const double minTouchTargetSize = 48.0;
  static const double defaultFontSize = 16.0;
  static const double largeFontSize = 20.0;
  static const double smallFontSize = 12.0;
}
