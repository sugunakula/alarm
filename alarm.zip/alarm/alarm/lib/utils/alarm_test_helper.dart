import 'package:flutter/foundation.dart';
import 'package:alarm/alarm.dart';
import '../models/alarm_model.dart';
import '../services/alarm_service.dart';

class AlarmTestHelper {
  /// Creates a test alarm that will ring in 5 seconds
  /// Useful for testing the alarm dismissal functionality
  static Future<void> createTestAlarm() async {
    try {
      final testTime = DateTime.now().add(const Duration(seconds: 5));
      
      final testAlarm = AlarmModel(
        id: 999999, // Use a high ID to avoid conflicts
        label: 'Test Alarm',
        dateTime: testTime,
        gameType: GameType.mathEquation,
        isEnabled: true,
        soundId: 'classic_beep',
        vibrate: true,
        enableLight: true,
      );
      
      final alarmSettings = testAlarm.toAlarmSettings();
      await Alarm.set(alarmSettings: alarmSettings);
      
      debugPrint('Test alarm created! Will ring at: ${testTime.toString()}');
      debugPrint('Current time: ${DateTime.now().toString()}');
      
      // Also manually trigger the check after a delay to ensure it works
      Future.delayed(const Duration(seconds: 6), () {
        debugPrint('Manually checking for ringing alarms after test delay');
        AlarmService.checkForRingingAlarms();
      });
      
    } catch (e) {
      debugPrint('Error creating test alarm: $e');
    }
  }
  
  /// Lists all currently set alarms
  static void listCurrentAlarms() {
    final alarms = Alarm.getAlarms();
    debugPrint('Currently set alarms: ${alarms.length}');
    for (final alarm in alarms) {
      debugPrint('  - ID: ${alarm.id}, DateTime: ${alarm.dateTime}');
    }
  }
  
  /// Stops all alarms (useful for testing)
  static Future<void> stopAllAlarms() async {
    final alarms = Alarm.getAlarms();
    for (final alarm in alarms) {
      await Alarm.stop(alarm.id);
      debugPrint('Stopped alarm ID: ${alarm.id}');
    }
  }
}
