import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:alarm/alarm.dart';
import 'package:permission_handler/permission_handler.dart';
import 'providers/alarm_provider.dart';
import 'providers/game_provider.dart';
import 'screens/splash_screen.dart';
import 'services/alarm_service.dart';
import 'utils/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize alarm
  await Alarm.init();
  
  // Request necessary permissions
  await _requestPermissions();
  
  runApp(const NoSnoozApp());
}

Future<void> _requestPermissions() async {
  // Request notification permission
  await Permission.notification.request();
  
  // Request system alert window permission for overlay
  await AlarmService.requestSystemAlertPermission();
  
  // Request audio permission
  await Permission.microphone.request();
  
  // Request storage permission for custom sounds
  await Permission.storage.request();
}

class NoSnoozApp extends StatefulWidget {
  const NoSnoozApp({super.key});

  @override
  State<NoSnoozApp> createState() => _NoSnoozAppState();
}

class _NoSnoozAppState extends State<NoSnoozApp> {
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      AlarmService.initialize(context);
    });
    
    // Set up app lifecycle listener to handle alarms when app is resumed
    WidgetsBinding.instance.addObserver(_AppLifecycleObserver());
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AlarmProvider()),
        ChangeNotifierProvider(create: (_) => GameProvider()),
      ],
      child: MaterialApp(
        title: 'NoSnooz',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const SplashScreen(),
        navigatorKey: _navigatorKey,
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          // Set the context for AlarmService after MaterialApp is built
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (_navigatorKey.currentContext != null) {
              AlarmService.initialize(_navigatorKey.currentContext!);
            }
          });
          return child!;
        },
      ),
    );
  }
}

class _AppLifecycleObserver extends WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    
    switch (state) {
      case AppLifecycleState.resumed:
        // When app is brought to foreground, check for ringing alarms
        debugPrint('App resumed - checking for ringing alarms');
        AlarmService.checkForRingingAlarms();
        break;
      case AppLifecycleState.paused:
        debugPrint('App paused');
        break;
      case AppLifecycleState.inactive:
        debugPrint('App inactive');
        break;
      case AppLifecycleState.detached:
        debugPrint('App detached');
        break;
      case AppLifecycleState.hidden:
        debugPrint('App hidden');
        break;
    }
  }
}

