import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/alarm_model.dart';
import '../models/game_model.dart';

class GameProvider extends ChangeNotifier {
  Map<GameType, GameStats> _gameStats = {};
  GameStatus _currentGameStatus = GameStatus.notStarted;
  GameType? _currentGame;
  GameConfig _currentConfig = const GameConfig();
  DateTime? _gameStartTime;
  int _currentAttempts = 0;
  bool _isLoading = false;

  // Getters
  Map<GameType, GameStats> get gameStats => _gameStats;
  GameStatus get currentGameStatus => _currentGameStatus;
  GameType? get currentGame => _currentGame;
  GameConfig get currentConfig => _currentConfig;
  int get currentAttempts => _currentAttempts;
  bool get isLoading => _isLoading;

  bool get isGameActive => 
      _currentGameStatus == GameStatus.playing;

  Duration? get gameElapsedTime {
    if (_gameStartTime == null) return null;
    return DateTime.now().difference(_gameStartTime!);
  }

  int get remainingTime {
    if (_gameStartTime == null) return _currentConfig.timeLimit;
    final elapsed = gameElapsedTime!.inSeconds;
    return math.max(0, _currentConfig.timeLimit - elapsed);
  }

  bool get isTimeUp => remainingTime <= 0;

  Future<void> loadGameStats() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      
      for (final gameType in GameType.values) {
        final key = 'game_stats_${gameType.name}';
        final statsJson = prefs.getString(key);
        
        if (statsJson != null) {
          final statsMap = jsonDecode(statsJson);
          _gameStats[gameType] = GameStats.fromJson(statsMap);
        } else {
          _gameStats[gameType] = GameStats(
            totalPlayed: 0,
            totalCompleted: 0,
            totalFailed: 0,
            averageTime: Duration.zero,
            bestScore: 0,
            lastPlayed: DateTime.now(),
          );
        }
      }
    } catch (e) {
      debugPrint('Error loading game stats: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> startGame(GameType gameType, {GameConfig? config}) async {
    _currentGame = gameType;
    _currentConfig = config ?? const GameConfig();
    _currentGameStatus = GameStatus.playing;
    _gameStartTime = DateTime.now();
    _currentAttempts = 0;
    
    notifyListeners();
  }

  Future<void> completeGame(GameResult result) async {
    if (_currentGame == null || _currentGameStatus != GameStatus.playing) {
      return;
    }

    _currentGameStatus = result.isSuccess ? GameStatus.completed : GameStatus.failed;
    
    // Update game statistics
    await _updateGameStats(_currentGame!, result);
    
    notifyListeners();
  }

  Future<void> resetGame() async {
    _currentGame = null;
    _currentGameStatus = GameStatus.notStarted;
    _currentConfig = const GameConfig();
    _gameStartTime = null;
    _currentAttempts = 0;
    
    notifyListeners();
  }

  void incrementAttempts() {
    _currentAttempts++;
    notifyListeners();
  }

  bool get hasAttemptsRemaining => 
      _currentAttempts < _currentConfig.maxAttempts;

  GameType getRandomGameType({bool premiumOnly = false}) {
    final implementedGames = [
      GameType.mathEquation,
      GameType.findTheBall,
      GameType.colorMatchBlitz,
      GameType.memoryFlip,
      GameType.puzzleSolve,
    ];
    
    final availableGames = premiumOnly 
        ? implementedGames 
        : [GameType.mathEquation]; // Free users get only math game
    
    final random = Random();
    return availableGames[random.nextInt(availableGames.length)];
  }

  GameConfig getGameConfig(GameType gameType, {GameDifficulty? difficulty}) {
    difficulty ??= _getAdaptiveDifficulty(gameType);
    
    switch (gameType) {
      case GameType.mathEquation:
        return GameConfig(
          difficulty: difficulty,
          timeLimit: difficulty == GameDifficulty.easy ? 30 : 
                    difficulty == GameDifficulty.medium ? 45 : 60,
          maxAttempts: 3,
          enableHints: difficulty == GameDifficulty.easy,
        );
      
      case GameType.findTheBall:
        return GameConfig(
          difficulty: difficulty,
          timeLimit: 60,
          maxAttempts: difficulty == GameDifficulty.hard ? 1 : 2,
        );
      
      case GameType.puzzleSolve:
        return GameConfig(
          difficulty: difficulty,
          timeLimit: difficulty == GameDifficulty.easy ? 90 : 
                    difficulty == GameDifficulty.medium ? 120 : 180,
          maxAttempts: 5,
          enableHints: true,
        );
      
      case GameType.colorMatchBlitz:
        return GameConfig(
          difficulty: difficulty,
          timeLimit: difficulty == GameDifficulty.easy ? 45 : 
                    difficulty == GameDifficulty.medium ? 60 : 90,
          maxAttempts: 3,
        );
      
      case GameType.memoryFlip:
        return GameConfig(
          difficulty: difficulty,
          timeLimit: 120,
          maxAttempts: difficulty == GameDifficulty.easy ? 5 : 
                     difficulty == GameDifficulty.medium ? 4 : 3,
        );
    }
  }

  GameDifficulty _getAdaptiveDifficulty(GameType gameType) {
    final stats = _gameStats[gameType];
    if (stats == null || stats.totalPlayed < 3) {
      return GameDifficulty.easy;
    }
    
    final successRate = stats.successRate;
    
    if (successRate >= 0.8) {
      return GameDifficulty.hard;
    } else if (successRate >= 0.6) {
      return GameDifficulty.medium;
    } else {
      return GameDifficulty.easy;
    }
  }

  Future<void> _updateGameStats(GameType gameType, GameResult result) async {
    final currentStats = _gameStats[gameType] ?? GameStats(
      totalPlayed: 0,
      totalCompleted: 0,
      totalFailed: 0,
      averageTime: Duration.zero,
      bestScore: 0,
      lastPlayed: DateTime.now(),
    );

    final newTotalPlayed = currentStats.totalPlayed + 1;
    final newCompleted = result.isSuccess 
        ? currentStats.totalCompleted + 1 
        : currentStats.totalCompleted;
    final newFailed = !result.isSuccess 
        ? currentStats.totalFailed + 1 
        : currentStats.totalFailed;

    // Calculate new average time
    final totalTime = currentStats.averageTime.inMilliseconds * currentStats.totalPlayed;
    final newAverageTime = Duration(
      milliseconds: ((totalTime + result.timeTaken.inMilliseconds) / newTotalPlayed).round(),
    );

    final newBestScore = math.max(currentStats.bestScore, result.score);

    final updatedStats = GameStats(
      totalPlayed: newTotalPlayed,
      totalCompleted: newCompleted,
      totalFailed: newFailed,
      averageTime: newAverageTime,
      bestScore: newBestScore,
      lastPlayed: DateTime.now(),
    );

    _gameStats[gameType] = updatedStats;

    // Save to preferences
    await _saveGameStats(gameType, updatedStats);
  }

  Future<void> _saveGameStats(GameType gameType, GameStats stats) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'game_stats_${gameType.name}';
      await prefs.setString(key, jsonEncode(stats.toJson()));
    } catch (e) {
      debugPrint('Error saving game stats: $e');
    }
  }

  // Get game display information
  Map<String, dynamic> getGameInfo(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return {
          'name': 'Math Equation',
          'description': 'Solve arithmetic problems to dismiss your alarm',
          'icon': Icons.calculate,
          'color': const Color(0xFF4CAF50),
          'isPremium': false,
        };
      
      case GameType.findTheBall:
        return {
          'name': 'Find The Ball',
          'description': 'Track the ball under moving cups',
          'icon': Icons.sports_baseball,
          'color': const Color(0xFF9C27B0),
          'isPremium': true,
        };
      
      case GameType.puzzleSolve:
        return {
          'name': 'Puzzle Solve',
          'description': 'Complete the sliding puzzle challenge',
          'icon': Icons.extension,
          'color': const Color(0xFFFF5722),
          'isPremium': true,
        };
      
      case GameType.colorMatchBlitz:
        return {
          'name': 'Color Match Blitz',
          'description': 'Match colors as fast as you can',
          'icon': Icons.palette,
          'color': const Color(0xFFE91E63),
          'isPremium': true,
        };
      
      case GameType.memoryFlip:
        return {
          'name': 'Memory Flip',
          'description': 'Remember and match the card pairs',
          'icon': Icons.psychology,
          'color': const Color(0xFF00BCD4),
          'isPremium': true,
        };
    }
  }

  List<GameType> get availableGames => GameType.values;
  
  List<GameType> get freeGames => [GameType.mathEquation];
  
  List<GameType> get premiumGames => GameType.values.where(
    (game) => !freeGames.contains(game),
  ).toList();
}
