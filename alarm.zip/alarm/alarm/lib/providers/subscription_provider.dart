import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/subscription_model.dart';

class SubscriptionProvider extends ChangeNotifier {
  UserSubscription _subscription = UserSubscription.defaultFree;
  bool _isLoading = false;
  String? _error;
  List<ProductDetails> _products = [];
  bool _purchaseInProgress = false;

  // Getters
  UserSubscription get subscription => _subscription;
  bool get isLoading => _isLoading;
  String? get error => _error;
  List<ProductDetails> get products => _products;
  bool get purchaseInProgress => _purchaseInProgress;

  bool get isPremium => _subscription.isPremium && _subscription.isActive;
  bool get isTrialActive => _subscription.isTrialActive;
  bool get isSubscriptionExpired => _subscription.isExpired;

  Future<void> initialize() async {
    _setLoading(true);
    
    try {
      // Load subscription from storage
      await _loadSubscription();
      
      // Initialize in-app purchases
      await _initializeInAppPurchases();
      
      // Verify subscription status
      await _verifySubscription();
    } catch (e) {
      _setError('Failed to initialize subscription: ${e.toString()}');
    } finally {
      _setLoading(false);
    }
  }

  Future<void> _loadSubscription() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final subscriptionJson = prefs.getString('user_subscription');
      
      if (subscriptionJson != null) {
        final subscriptionMap = jsonDecode(subscriptionJson);
        _subscription = UserSubscription.fromJson(subscriptionMap);
      }
    } catch (e) {
      debugPrint('Error loading subscription: $e');
    }
  }

  Future<void> _saveSubscription() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_subscription', jsonEncode(_subscription.toJson()));
    } catch (e) {
      debugPrint('Error saving subscription: $e');
    }
  }

  Future<void> _initializeInAppPurchases() async {
    try {
      final available = await InAppPurchase.instance.isAvailable();
      if (!available) {
        _setError('In-app purchases not available');
        return;
      }

      // Get product details
      const productIds = {'nosnooz_monthly', 'nosnooz_yearly'};
      final response = await InAppPurchase.instance.queryProductDetails(productIds);
      
      if (response.error != null) {
        _setError('Failed to load products: ${response.error!.message}');
        return;
      }

      _products = response.productDetails;
      
      // Listen to purchase updates
      InAppPurchase.instance.purchaseStream.listen(_handlePurchaseUpdate);
    } catch (e) {
      _setError('Failed to initialize purchases: ${e.toString()}');
    }
  }

  Future<void> _verifySubscription() async {
    try {
      // Check if subscription is still valid by querying past purchases
      final response = await InAppPurchase.instance.restorePurchases();
      
      if (response.isEmpty && _subscription.isPremium) {
        // No active purchases found, revert to free
        await _updateSubscription(UserSubscription.defaultFree);
      }
    } catch (e) {
      debugPrint('Error verifying subscription: $e');
    }
  }

  void _handlePurchaseUpdate(List<PurchaseDetails> purchases) {
    for (final purchase in purchases) {
      _processPurchase(purchase);
    }
  }

  Future<void> _processPurchase(PurchaseDetails purchase) async {
    if (purchase.status == PurchaseStatus.purchased) {
      // Purchase successful
      await _handleSuccessfulPurchase(purchase);
    } else if (purchase.status == PurchaseStatus.error) {
      // Purchase failed
      _setError('Purchase failed: ${purchase.error?.message ?? 'Unknown error'}');
    } else if (purchase.status == PurchaseStatus.canceled) {
      _setError('Purchase was canceled');
    }

    // Complete the purchase
    if (purchase.pendingCompletePurchase) {
      await InAppPurchase.instance.completePurchase(purchase);
    }

    _purchaseInProgress = false;
    notifyListeners();
  }

  Future<void> _handleSuccessfulPurchase(PurchaseDetails purchase) async {
    final plan = SubscriptionPlan.availablePlans.firstWhere(
      (p) => p.id == purchase.productID,
      orElse: () => SubscriptionPlan.availablePlans.first,
    );

    final now = DateTime.now();
    final expirationDate = plan.period == SubscriptionPeriod.monthly
        ? now.add(const Duration(days: 30))
        : now.add(const Duration(days: 365));

    final newSubscription = _subscription.copyWith(
      tier: SubscriptionTier.premium,
      planId: plan.id,
      purchaseDate: now,
      expirationDate: expirationDate,
      isTrialActive: false,
      autoRenew: true,
    );

    await _updateSubscription(newSubscription);
    _clearError();
  }

  Future<void> purchaseSubscription(String productId) async {
    if (_purchaseInProgress) return;

    try {
      _purchaseInProgress = true;
      notifyListeners();

      final product = _products.firstWhere(
        (p) => p.id == productId,
        orElse: () => throw Exception('Product not found'),
      );

      final purchaseParam = PurchaseParam(productDetails: product);
      await InAppPurchase.instance.buyNonConsumable(purchaseParam: purchaseParam);
    } catch (e) {
      _purchaseInProgress = false;
      _setError('Failed to purchase subscription: ${e.toString()}');
      notifyListeners();
    }
  }

  Future<void> startTrial(String productId) async {
    if (_subscription.isTrialActive || _subscription.isPremium) {
      _setError('Trial already used or premium subscription active');
      return;
    }

    try {
      final plan = SubscriptionPlan.availablePlans.firstWhere(
        (p) => p.id == productId,
        orElse: () => throw Exception('Plan not found'),
      );

      if (!plan.hasTrial) {
        _setError('This plan does not offer a trial');
        return;
      }

      final now = DateTime.now();
      final trialEnd = now.add(Duration(days: plan.trialDays));

      final trialSubscription = _subscription.copyWith(
        tier: SubscriptionTier.premium,
        planId: plan.id,
        purchaseDate: now,
        isTrialActive: true,
        trialEndDate: trialEnd,
      );

      await _updateSubscription(trialSubscription);
      _clearError();
    } catch (e) {
      _setError('Failed to start trial: ${e.toString()}');
    }
  }

  Future<void> cancelSubscription() async {
    try {
      // Note: Actual cancellation happens through the platform store
      // This method is for UI purposes and local state management
      
      final canceledSubscription = _subscription.copyWith(
        autoRenew: false,
      );

      await _updateSubscription(canceledSubscription);
    } catch (e) {
      _setError('Failed to cancel subscription: ${e.toString()}');
    }
  }

  Future<void> restorePurchases() async {
    try {
      _setLoading(true);
      await InAppPurchase.instance.restorePurchases();
    } catch (e) {
      _setError('Failed to restore purchases: ${e.toString()}');
    } finally {
      _setLoading(false);
    }
  }

  bool canAccessFeature(String featureName) {
    if (!isPremium) {
      // Free tier limitations
      switch (featureName) {
        case 'premium_games':
        case 'custom_sounds':
        case 'unlimited_alarms':
        case 'advanced_customization':
          return false;
        default:
          return true;
      }
    }
    return true;
  }

  List<String> get availableFeatures {
    if (isPremium) {
      return [
        'All 5 mini-games unlocked',
        'Advanced customization options',
        'Priority customer support',
        'No ads',
        'Custom alarm sounds',
        'Unlimited alarms',
      ];
    }
    return [
      'Basic alarm functionality',
      'Math equation game',
      'Up to 5 alarms',
    ];
  }

  String get subscriptionStatusText {
    if (_subscription.tier == SubscriptionTier.free) {
      return 'Free Plan';
    }
    
    if (_subscription.isTrialActive) {
      final days = _subscription.daysRemaining;
      return 'Trial - $days days remaining';
    }
    
    if (_subscription.isActive) {
      final days = _subscription.daysRemaining;
      return 'Premium - $days days remaining';
    }
    
    return 'Subscription Expired';
  }

  Future<void> _updateSubscription(UserSubscription newSubscription) async {
    _subscription = newSubscription;
    await _saveSubscription();
    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _error = error;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    notifyListeners();
  }

  @override
  void dispose() {
    InAppPurchase.instance.purchaseStream.drain();
    super.dispose();
  }
}
