import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:alarm/alarm.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/alarm_model.dart';

class AlarmProvider extends ChangeNotifier {
  List<AlarmModel> _alarms = [];
  bool _isLoading = false;
  String? _error;
  bool _isDismissingAlarm = false;

  List<AlarmModel> get alarms => _alarms;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isDismissingAlarm => _isDismissingAlarm;

  List<AlarmModel> get activeAlarms => 
      _alarms.where((alarm) => alarm.isEnabled).toList();

  AlarmModel? get nextAlarm {
    final active = activeAlarms;
    if (active.isEmpty) return null;
    
    active.sort((a, b) {
      final nextA = a.getNextAlarmTime();
      final nextB = b.getNextAlarmTime();
      if (nextA == null && nextB == null) return 0;
      if (nextA == null) return 1;
      if (nextB == null) return -1;
      return nextA.compareTo(nextB);
    });
    
    return active.first;
  }

  Future<void> loadAlarms() async {
    _setLoading(true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final alarmStrings = prefs.getStringList('alarms') ?? [];
      
      _alarms = alarmStrings.map((alarmString) {
        final json = jsonDecode(alarmString);
        return AlarmModel.fromJson(json);
      }).toList();
      
      // Sync with system alarms
      await _syncWithSystemAlarms();
      
      _error = null;
    } catch (e) {
      _error = 'Failed to load alarms: ${e.toString()}';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addAlarm(AlarmModel alarm) async {
    try {
      _alarms.add(alarm);
      await _saveAlarms();
      
      if (alarm.isEnabled) {
        await _scheduleSystemAlarm(alarm);
      }
      
      notifyListeners();
    } catch (e) {
      _error = 'Failed to add alarm: ${e.toString()}';
      notifyListeners();
    }
  }

  Future<void> updateAlarm(AlarmModel updatedAlarm) async {
    try {
      final index = _alarms.indexWhere((alarm) => alarm.id == updatedAlarm.id);
      if (index != -1) {
        // Cancel existing system alarm
        await Alarm.stop(updatedAlarm.id);
        
        _alarms[index] = updatedAlarm;
        await _saveAlarms();
        
        if (updatedAlarm.isEnabled) {
          await _scheduleSystemAlarm(updatedAlarm);
        }
        
        notifyListeners();
      }
    } catch (e) {
      _error = 'Failed to update alarm: ${e.toString()}';
      notifyListeners();
    }
  }

  Future<void> deleteAlarm(int alarmId) async {
    try {
      await Alarm.stop(alarmId);
      _alarms.removeWhere((alarm) => alarm.id == alarmId);
      await _saveAlarms();
      notifyListeners();
    } catch (e) {
      _error = 'Failed to delete alarm: ${e.toString()}';
      notifyListeners();
    }
  }

  Future<void> toggleAlarm(int alarmId) async {
    try {
      final index = _alarms.indexWhere((alarm) => alarm.id == alarmId);
      if (index != -1) {
        final alarm = _alarms[index];
        final updatedAlarm = alarm.copyWith(isEnabled: !alarm.isEnabled);
        await updateAlarm(updatedAlarm);
      }
    } catch (e) {
      _error = 'Failed to toggle alarm: ${e.toString()}';
      notifyListeners();
    }
  }

  Future<void> dismissAlarm(int alarmId) async {
    _isDismissingAlarm = true;
    notifyListeners();
    
    try {
      await Alarm.stop(alarmId);
      
      final index = _alarms.indexWhere((alarm) => alarm.id == alarmId);
      if (index != -1) {
        final alarm = _alarms[index];
        
        // If it's a repeating alarm, schedule the next occurrence
        if (alarm.repeatOption != RepeatOption.never) {
          final nextTime = alarm.getNextAlarmTime();
          if (nextTime != null) {
            final nextAlarm = alarm.copyWith(dateTime: nextTime);
            await _scheduleSystemAlarm(nextAlarm);
            _alarms[index] = nextAlarm;
            await _saveAlarms();
          }
        } else {
          // For one-time alarms, disable them after ringing
          final disabledAlarm = alarm.copyWith(isEnabled: false);
          _alarms[index] = disabledAlarm;
          await _saveAlarms();
        }
      }
      
      // Add a delay to ensure system alarm is fully stopped
      await Future.delayed(const Duration(milliseconds: 500));
      
    } catch (e) {
      _error = 'Failed to dismiss alarm: ${e.toString()}';
    } finally {
      _isDismissingAlarm = false;
      notifyListeners();
    }
  }

  int generateAlarmId() {
    if (_alarms.isEmpty) return 1;
    return _alarms.map((alarm) => alarm.id).reduce((a, b) => a > b ? a : b) + 1;
  }

  Future<void> _scheduleSystemAlarm(AlarmModel alarm) async {
    final alarmSettings = alarm.toAlarmSettings();
    await Alarm.set(alarmSettings: alarmSettings);
  }

  Future<void> _saveAlarms() async {
    final prefs = await SharedPreferences.getInstance();
    final alarmStrings = _alarms.map((alarm) => jsonEncode(alarm.toJson())).toList();
    await prefs.setStringList('alarms', alarmStrings);
  }

  Future<void> _syncWithSystemAlarms() async {
    final systemAlarms = Alarm.getAlarms();
    final alarmIds = systemAlarms.map((alarm) => alarm.id).toList();
    
    // Remove alarms that are no longer in the system
    _alarms.removeWhere((alarm) => 
        alarm.isEnabled && !alarmIds.contains(alarm.id));
    
    // Re-schedule active alarms that aren't in the system
    for (final alarm in _alarms) {
      if (alarm.isEnabled && !alarmIds.contains(alarm.id)) {
        await _scheduleSystemAlarm(alarm);
      }
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  Future<void> refreshAlarms() async {
    await loadAlarms();
  }

  // Check if any alarms are currently ringing
  bool get hasRingingAlarms {
    // Don't show ringing alarms if we're in the process of dismissing
    if (_isDismissingAlarm) return false;
    return Alarm.getAlarms().isNotEmpty;
  }

  // Get the currently ringing alarm
  AlarmModel? get ringingAlarm {
    // Don't return ringing alarm if we're in the process of dismissing
    if (_isDismissingAlarm) return null;
    
    final systemAlarms = Alarm.getAlarms();
    if (systemAlarms.isEmpty) return null;
    
    final ringingId = systemAlarms.first.id;
    return _alarms.firstWhere(
      (alarm) => alarm.id == ringingId,
      orElse: () => _alarms.first,
    );
  }
}
