import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';

class ColorMatchBlitzGame extends StatefulWidget {
  final GameConfig? config;
  final Function(GameResult)? onGameComplete;
  final Function(bool, int)? onGameResult;
  final bool isPracticeMode;

  const ColorMatchBlitzGame({
    super.key,
    this.config,
    this.onGameComplete,
    this.onGameResult,
    this.isPracticeMode = false,
  });

  @override
  State<ColorMatchBlitzGame> createState() => _ColorMatchBlitzGameState();
}

class _ColorMatchBlitzGameState extends State<ColorMatchBlitzGame>
    with TickerProviderStateMixin {
  late AnimationController _timerController;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _successController;
  late Animation<double> _successAnimation;

  final List<Color> _gameColors = [
    Colors.red,
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.purple,
    Colors.orange,
    Colors.pink,
    Colors.cyan,
  ];

  final List<String> _colorNames = [
    'RED',
    'BLUE',
    'GREEN',
    'YELLOW',
    'PURPLE',
    'ORANGE',
    'PINK',
    'CYAN',
  ];

  Color _targetColor = Colors.red;
  String _displayedText = 'RED';
  Color _textColor = Colors.red;
  List<Color> _optionColors = [];
  int _score = 0;
  int _currentRound = 1;
  int _wrongAttempts = 0;
  int _streak = 0;
  bool _isGameComplete = false;
  DateTime? _startTime;
  
  int get _totalRounds => (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.easy 
      ? 10 
      : (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.medium 
          ? 15 
          : 20;

  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeGame();
  }

  void _initializeAnimations() {
    _timerController = AnimationController(
      duration: Duration(seconds: widget.config?.timeLimit ?? 60),
      vsync: this,
    );

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _successController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _successAnimation = Tween<double>(
      begin: 1.0,
      end: 1.5,
    ).animate(CurvedAnimation(
      parent: _successController,
      curve: Curves.elasticOut,
    ));

    _timerController.addListener(() {
      if (_timerController.isCompleted && !_isGameComplete) {
        _endGame(false);
      }
    });

    _pulseController.repeat(reverse: true);
    _timerController.forward();
  }

  void _initializeGame() {
    _startTime = DateTime.now();
    _generateNewChallenge();
  }

  void _generateNewChallenge() {
    setState(() {
      // Choose a random target color
      _targetColor = _gameColors[_random.nextInt(_gameColors.length)];
      
      // Generate challenge based on difficulty
      switch (widget.config?.difficulty ?? GameDifficulty.medium) {
        case GameDifficulty.easy:
          _generateEasyChallenge();
          break;
        case GameDifficulty.medium:
          _generateMediumChallenge();
          break;
        case GameDifficulty.hard:
          _generateHardChallenge();
          break;
      }
      
      _generateOptions();
    });
  }

  void _generateEasyChallenge() {
    // Easy: Color name matches color (straightforward)
    final colorIndex = _gameColors.indexOf(_targetColor);
    _displayedText = _colorNames[colorIndex];
    _textColor = _targetColor;
  }

  void _generateMediumChallenge() {
    // Medium: Color name in different color (Stroop effect)
    final targetIndex = _gameColors.indexOf(_targetColor);
    _displayedText = _colorNames[targetIndex];
    
    // Make text color different from target color
    Color differentColor;
    do {
      differentColor = _gameColors[_random.nextInt(_gameColors.length)];
    } while (differentColor == _targetColor);
    
    _textColor = differentColor;
  }

  void _generateHardChallenge() {
    // Hard: Random color name in random color (maximum confusion)
    _displayedText = _colorNames[_random.nextInt(_colorNames.length)];
    _textColor = _gameColors[_random.nextInt(_gameColors.length)];
  }

  void _generateOptions() {
    _optionColors = [_targetColor];
    
    // Add 3 more random colors
    while (_optionColors.length < 4) {
      final randomColor = _gameColors[_random.nextInt(_gameColors.length)];
      if (!_optionColors.contains(randomColor)) {
        _optionColors.add(randomColor);
      }
    }
    
    _optionColors.shuffle();
  }

  void _selectColor(Color selectedColor) {
    if (_isGameComplete) return;

    if (selectedColor == _targetColor) {
      _handleCorrectAnswer();
    } else {
      _handleWrongAnswer();
    }
  }

  void _handleCorrectAnswer() {
    _streak++;
    final roundScore = _calculateScore();
    _score += roundScore;
    
    _successController.forward().then((_) {
      _successController.reset();
    });

    _currentRound++;
    
    if (_currentRound > _totalRounds) {
      _endGame(true);
    } else {
      Future.delayed(const Duration(milliseconds: 400), () {
        if (!_isGameComplete) {
          _generateNewChallenge();
        }
      });
    }
  }

  void _handleWrongAnswer() {
    _wrongAttempts++;
    _streak = 0; // Reset streak on wrong answer
    
    if (_wrongAttempts >= (widget.config?.maxAttempts ?? 3)) {
      _endGame(false);
    } else {
      // Show feedback and continue
      Future.delayed(const Duration(milliseconds: 600), () {
        if (!_isGameComplete) {
          _generateNewChallenge();
        }
      });
    }
  }

  int _calculateScore() {
    int baseScore = (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.easy 
        ? 10 
        : (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.medium 
            ? 20 
            : 30;
    
    // Streak bonus
    int streakBonus = _streak >= 5 ? 10 : _streak >= 3 ? 5 : 0;
    
    // Speed bonus
    final timeLimit = widget.config?.timeLimit ?? 60;
    final remainingTime = timeLimit - _timerController.value * timeLimit;
    final speedBonus = (remainingTime / timeLimit * 15).round();
    
    return baseScore + streakBonus + speedBonus;
  }

  void _endGame(bool success) {
    if (_isGameComplete) return;
    
    _isGameComplete = true;
    _timerController.stop();
    _pulseController.stop();

    final timeTaken = _startTime != null 
        ? DateTime.now().difference(_startTime!) 
        : Duration.zero;

    final result = GameResult(
      isSuccess: success,
      score: _score,
      timeTaken: timeTaken,
      attempts: _wrongAttempts + 1,
    );

    widget.onGameComplete?.call(result);
  }

  @override
  void dispose() {
    _timerController.dispose();
    _pulseController.dispose();
    _successController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Color Match Blitz'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                'Score: $_score',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Progress indicators
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(
                    value: _timerController.value,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _timerController.value > 0.7 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Text('$_currentRound/$_totalRounds'),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Streak indicator
            if (_streak > 0) ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.orange),
                ),
                child: Text(
                  'Streak: $_streak 🔥',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.orange,
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
            
            // Instructions
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Icon(
                      Icons.palette,
                      size: 48,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _getInstructionText(),
                      style: Theme.of(context).textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Color word display
            Expanded(
              child: Center(
                child: AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return AnimatedBuilder(
                      animation: _successAnimation,
                      builder: (context, child) {
                        return Transform.scale(
                          scale: _pulseAnimation.value * _successAnimation.value,
                          child: Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: _textColor.withOpacity(0.3),
                                  blurRadius: 20,
                                  spreadRadius: 5,
                                ),
                              ],
                            ),
                            child: Text(
                              _displayedText,
                              style: TextStyle(
                                fontSize: 48,
                                fontWeight: FontWeight.bold,
                                color: _textColor,
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
            
            const SizedBox(height: 32),
            
            // Color options
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemCount: _optionColors.length,
              itemBuilder: (context, index) {
                final color = _optionColors[index];
                return _buildColorOption(color);
              },
            ),
            
            const SizedBox(height: 16),
            
            // Attempts remaining
            if (_wrongAttempts > 0) ...[
              Text(
                'Wrong attempts: $_wrongAttempts/${widget.config?.maxAttempts ?? 3}',
                style: TextStyle(
                  color: Colors.red[700],
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _getInstructionText() {
    switch (widget.config?.difficulty ?? GameDifficulty.medium) {
      case GameDifficulty.easy:
        return 'Tap the color that matches the word meaning!';
      case GameDifficulty.medium:
        return 'Tap the color that matches the WORD, not the text color!';
      case GameDifficulty.hard:
        return 'Find the target color! Ignore the word and text color.';
    }
  }

  Widget _buildColorOption(Color color) {
    return Material(
      elevation: 4,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () => _selectColor(color),
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Center(
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.touch_app,
                color: Colors.white,
                size: 30,
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  void _completeGame(bool success) {
    if (widget.isPracticeMode) {
      _showResultDialog(success);
    } else {
      if (widget.onGameResult != null) {
        widget.onGameResult!(success, _score);
      } else if (widget.onGameComplete != null) {
        final result = GameResult(
          isSuccess: success,
          score: _score,
          timeTaken: DateTime.now().difference(_startTime!),
          attempts: _wrongAttempts + 1,
        );
        widget.onGameComplete?.call(result);
      }
    }
  }
  
  void _showResultDialog(bool success) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(success ? 'Great Job!' : 'Try Again!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              success ? Icons.check_circle : Icons.cancel,
              size: 64,
              color: success ? Colors.green : Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              success 
                  ? 'You mastered the color matching challenge!'
                  : 'Keep practicing to improve your color recognition!',
            ),
            const SizedBox(height: 8),
            Text('Score: $_score'),
            const SizedBox(height: 8),
            Text('Colors matched: $_correctAnswers'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Close game screen
            },
            child: const Text('Done'),
          ),
          if (!success)
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Reset game
                setState(() {
                  _score = 0;
                  _correctAnswers = 0;
                  _wrongAttempts = 0;
                  _targetColor = Colors.red;
                });
                _initializeGame();
              },
              child: const Text('Try Again'),
            ),
        ],
      ),
    );
  }
}
