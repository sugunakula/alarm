import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';

class MemoryCard {
  final int id;
  final IconData icon;
  bool isFlipped;
  bool isMatched;

  MemoryCard({
    required this.id,
    required this.icon,
    this.isFlipped = false,
    this.isMatched = false,
  });
}

class MemoryFlipGame extends StatefulWidget {
  final GameConfig config;
  final Function(GameResult) onGameComplete;

  const MemoryFlipGame({
    super.key,
    required this.config,
    required this.onGameComplete,
  });

  @override
  State<MemoryFlipGame> createState() => _MemoryFlipGameState();
}

class _MemoryFlipGameState extends State<MemoryFlipGame>
    with TickerProviderStateMixin {
  late AnimationController _timerController;
  late AnimationController _flipController;
  late Animation<double> _flipAnimation;

  List<MemoryCard> _cards = [];
  List<int> _selectedCards = [];
  int _matchedPairs = 0;
  int _totalPairs = 0;
  int _moves = 0;
  int _score = 0;
  int _wrongAttempts = 0;
  bool _isProcessing = false;
  bool _isGameComplete = false;
  DateTime? _startTime;

  final List<IconData> _availableIcons = [
    Icons.star,
    Icons.favorite,
    Icons.home,
    Icons.work,
    Icons.school,
    Icons.shopping_cart,
    Icons.phone,
    Icons.email,
    Icons.music_note,
    Icons.camera,
    Icons.games,
    Icons.sports_soccer,
    Icons.restaurant,
    Icons.local_cafe,
    Icons.flight,
    Icons.directions_car,
    Icons.pets,
    Icons.beach_access,
    Icons.wb_sunny,
    Icons.ac_unit,
  ];

  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeGame();
  }

  void _initializeAnimations() {
    _timerController = AnimationController(
      duration: Duration(seconds: widget.config.timeLimit),
      vsync: this,
    );

    _flipController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _flipAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _flipController,
      curve: Curves.easeInOut,
    ));

    _timerController.addListener(() {
      if (_timerController.isCompleted && !_isGameComplete) {
        _endGame(false);
      }
    });

    _timerController.forward();
  }

  void _initializeGame() {
    _startTime = DateTime.now();
    _setupCards();
  }

  void _setupCards() {
    // Determine grid size based on difficulty
    int pairsCount;
    switch (widget.config.difficulty) {
      case GameDifficulty.easy:
        pairsCount = 6; // 3x4 grid
        break;
      case GameDifficulty.medium:
        pairsCount = 8; // 4x4 grid
        break;
      case GameDifficulty.hard:
        pairsCount = 10; // 4x5 grid
        break;
    }

    _totalPairs = pairsCount;
    
    // Select random icons
    final selectedIcons = _availableIcons.take(pairsCount).toList();
    
    // Create pairs of cards
    _cards.clear();
    int cardId = 0;
    
    for (final icon in selectedIcons) {
      // Add two cards with the same icon
      _cards.add(MemoryCard(id: cardId++, icon: icon));
      _cards.add(MemoryCard(id: cardId++, icon: icon));
    }
    
    // Shuffle the cards
    _cards.shuffle(_random);
    
    setState(() {});
    
    // Show all cards briefly at the start
    _showAllCardsTemporarily();
  }

  void _showAllCardsTemporarily() {
    setState(() {
      for (var card in _cards) {
        card.isFlipped = true;
      }
    });
    
    // Hide cards after a brief moment
    Future.delayed(Duration(seconds: widget.config.enableHints ? 3 : 2), () {
      if (!_isGameComplete) {
        setState(() {
          for (var card in _cards) {
            card.isFlipped = false;
          }
        });
      }
    });
  }

  void _onCardTapped(int cardId) {
    if (_isProcessing || _isGameComplete) return;
    
    final cardIndex = _cards.indexWhere((card) => card.id == cardId);
    final card = _cards[cardIndex];
    
    // Can't tap already flipped or matched cards
    if (card.isFlipped || card.isMatched) return;
    
    // Can't select more than 2 cards
    if (_selectedCards.length >= 2) return;
    
    setState(() {
      card.isFlipped = true;
      _selectedCards.add(cardIndex);
    });
    
    _flipController.forward().then((_) {
      _flipController.reset();
    });
    
    // Check if we have 2 cards selected
    if (_selectedCards.length == 2) {
      _moves++;
      _checkForMatch();
    }
  }

  void _checkForMatch() {
    _isProcessing = true;
    
    final card1Index = _selectedCards[0];
    final card2Index = _selectedCards[1];
    final card1 = _cards[card1Index];
    final card2 = _cards[card2Index];
    
    // Delay to show both cards
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (card1.icon == card2.icon) {
        // Match found!
        _handleMatch(card1Index, card2Index);
      } else {
        // No match
        _handleNoMatch(card1Index, card2Index);
      }
      
      _selectedCards.clear();
      _isProcessing = false;
    });
  }

  void _handleMatch(int card1Index, int card2Index) {
    setState(() {
      _cards[card1Index].isMatched = true;
      _cards[card2Index].isMatched = true;
      _matchedPairs++;
    });
    
    // Add score for the match
    _score += _calculateMatchScore();
    
    // Check if game is won
    if (_matchedPairs == _totalPairs) {
      _endGame(true);
    }
  }

  void _handleNoMatch(int card1Index, int card2Index) {
    setState(() {
      _cards[card1Index].isFlipped = false;
      _cards[card2Index].isFlipped = false;
    });
    
    _wrongAttempts++;
    
    // Check if too many wrong attempts
    if (_wrongAttempts >= widget.config.maxAttempts) {
      _endGame(false);
    }
  }

  int _calculateMatchScore() {
    int baseScore = widget.config.difficulty == GameDifficulty.easy 
        ? 20 
        : widget.config.difficulty == GameDifficulty.medium 
            ? 30 
            : 40;
    
    // Bonus for fewer moves (efficiency)
    int moveBonus = 0;
    final optimalMoves = _totalPairs; // One move per pair is optimal
    if (_moves <= optimalMoves * 1.5) {
      moveBonus = 10;
    }
    
    // Time bonus
    final remainingTime = widget.config.timeLimit - _timerController.value * widget.config.timeLimit;
    final timeBonus = (remainingTime / widget.config.timeLimit * 15).round();
    
    return baseScore + moveBonus + timeBonus;
  }

  void _endGame(bool success) {
    if (_isGameComplete) return;
    
    _isGameComplete = true;
    _timerController.stop();

    final timeTaken = _startTime != null 
        ? DateTime.now().difference(_startTime!) 
        : Duration.zero;

    final result = GameResult(
      isSuccess: success,
      score: _score,
      timeTaken: timeTaken,
      attempts: _wrongAttempts + 1,
    );

    widget.onGameComplete(result);
  }

  @override
  void dispose() {
    _timerController.dispose();
    _flipController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Memory Flip'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                'Score: $_score',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Progress indicators
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(
                    value: _timerController.value,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _timerController.value > 0.7 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Text('$_matchedPairs/$_totalPairs pairs'),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Game stats
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatCard('Moves', _moves.toString(), Icons.touch_app),
                _buildStatCard('Pairs', '$_matchedPairs/$_totalPairs', Icons.psychology),
                _buildStatCard('Errors', _wrongAttempts.toString(), Icons.error_outline),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Game grid
            Expanded(
              child: _buildGameGrid(),
            ),
            
            const SizedBox(height: 16),
            
            // Instructions
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                  _isProcessing 
                      ? 'Checking match...' 
                      : 'Tap cards to flip them and find matching pairs!',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 4),
            Text(
              value,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameGrid() {
    // Determine grid dimensions based on card count
    int crossAxisCount;
    if (_cards.length <= 12) {
      crossAxisCount = 3;
    } else if (_cards.length <= 16) {
      crossAxisCount = 4;
    } else {
      crossAxisCount = 5;
    }

    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        childAspectRatio: 1,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: _cards.length,
      itemBuilder: (context, index) {
        return _buildCard(_cards[index]);
      },
    );
  }

  Widget _buildCard(MemoryCard card) {
    return GestureDetector(
      onTap: () => _onCardTapped(card.id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          color: card.isMatched 
              ? Colors.green[100] 
              : card.isFlipped 
                  ? Colors.blue[50] 
                  : Colors.grey[300],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: card.isMatched 
                ? Colors.green 
                : card.isFlipped 
                    ? Colors.blue 
                    : Colors.grey,
            width: 2,
          ),
          boxShadow: [
            if (card.isFlipped || card.isMatched)
              BoxShadow(
                color: (card.isMatched ? Colors.green : Colors.blue).withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
          ],
        ),
        child: Center(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: card.isFlipped || card.isMatched
                ? Icon(
                    card.icon,
                    size: 36,
                    color: card.isMatched ? Colors.green[700] : Colors.blue[700],
                    key: ValueKey('icon_${card.id}'),
                  )
                : Icon(
                    Icons.help_outline,
                    size: 36,
                    color: Colors.grey[600],
                    key: ValueKey('back_${card.id}'),
                  ),
          ),
        ),
      ),
    );
  }
}
