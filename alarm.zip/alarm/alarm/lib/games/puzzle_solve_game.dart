import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';

class PuzzleTile {
  final int value;
  final int correctPosition;
  bool isEmpty;

  PuzzleTile({
    required this.value,
    required this.correctPosition,
    this.isEmpty = false,
  });

  bool get isInCorrectPosition => value == correctPosition;
}

class PuzzleSolveGame extends StatefulWidget {
  final GameConfig? config;
  final Function(GameResult)? onGameComplete;
  final Function(bool, int)? onGameResult;
  final bool isPracticeMode;

  const PuzzleSolveGame({
    super.key,
    this.config,
    this.onGameComplete,
    this.onGameResult,
    this.isPracticeMode = false,
  });

  @override
  State<PuzzleSolveGame> createState() => _PuzzleSolveGameState();
}

class _PuzzleSolveGameState extends State<PuzzleSolveGame>
    with TickerProviderStateMixin {
  late AnimationController _timerController;
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  List<PuzzleTile> _tiles = [];
  int _gridSize = 3; // 3x3 puzzle for easy, 4x4 for medium, 5x5 for hard
  int _emptyTileIndex = 8; // Position of empty tile
  int _moves = 0;
  int _score = 0;
  int _wrongAttempts = 0;
  bool _isGameComplete = false;
  bool _isSolved = false;
  DateTime? _startTime;
  int? _slidingTileIndex;

  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeGame();
  }

  void _initializeAnimations() {
    _timerController = AnimationController(
      duration: Duration(seconds: widget.config?.timeLimit ?? 60),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeInOut,
    ));

    _timerController.addListener(() {
      if (_timerController.isCompleted && !_isGameComplete) {
        _endGame(false);
      }
    });

    _timerController.forward();
  }

  void _initializeGame() {
    _startTime = DateTime.now();
    _setupPuzzle();
  }

  void _setupPuzzle() {
    // Determine grid size based on difficulty
    switch (widget.config?.difficulty ?? GameDifficulty.medium) {
      case GameDifficulty.easy:
        _gridSize = 3; // 3x3 = 9 tiles (8 numbered + 1 empty)
        break;
      case GameDifficulty.medium:
        _gridSize = 4; // 4x4 = 16 tiles (15 numbered + 1 empty)
        break;
      case GameDifficulty.hard:
        _gridSize = 5; // 5x5 = 25 tiles (24 numbered + 1 empty)
        break;
    }

    final totalTiles = _gridSize * _gridSize;
    _emptyTileIndex = totalTiles - 1;

    // Create tiles in correct order
    _tiles.clear();
    for (int i = 0; i < totalTiles - 1; i++) {
      _tiles.add(PuzzleTile(
        value: i + 1,
        correctPosition: i + 1,
      ));
    }
    
    // Add empty tile
    _tiles.add(PuzzleTile(
      value: 0,
      correctPosition: 0,
      isEmpty: true,
    ));

    // Shuffle the puzzle
    _shufflePuzzle();
    
    setState(() {});
  }

  void _shufflePuzzle() {
    // Perform a series of valid moves to ensure the puzzle is solvable
    final shuffleMoves = (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.easy 
        ? 50 
        : (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.medium 
            ? 100 
            : 200;

    for (int i = 0; i < shuffleMoves; i++) {
      final validMoves = _getValidMoves();
      if (validMoves.isNotEmpty) {
        final randomMove = validMoves[_random.nextInt(validMoves.length)];
        _swapTiles(_emptyTileIndex, randomMove);
        _emptyTileIndex = randomMove;
      }
    }
    
    // Reset moves counter after shuffling
    _moves = 0;
  }

  List<int> _getValidMoves() {
    final validMoves = <int>[];
    final row = _emptyTileIndex ~/ _gridSize;
    final col = _emptyTileIndex % _gridSize;

    // Check up
    if (row > 0) {
      validMoves.add(_emptyTileIndex - _gridSize);
    }
    // Check down
    if (row < _gridSize - 1) {
      validMoves.add(_emptyTileIndex + _gridSize);
    }
    // Check left
    if (col > 0) {
      validMoves.add(_emptyTileIndex - 1);
    }
    // Check right
    if (col < _gridSize - 1) {
      validMoves.add(_emptyTileIndex + 1);
    }

    return validMoves;
  }

  void _onTileTapped(int tileIndex) {
    if (_isGameComplete || _isSolved || _slidingTileIndex != null) return;

    final validMoves = _getValidMoves();
    if (!validMoves.contains(tileIndex)) {
      // Invalid move - increase wrong attempts
      _wrongAttempts++;
      if (_wrongAttempts >= (widget.config?.maxAttempts ?? 3)) {
        _endGame(false);
      }
      return;
    }

    // Valid move - animate and swap
    _animateSlide(tileIndex, _emptyTileIndex, () {
      _swapTiles(tileIndex, _emptyTileIndex);
      _emptyTileIndex = tileIndex;
      _moves++;
      
      // Check if puzzle is solved
      if (_isPuzzleSolved()) {
        _isSolved = true;
        _score = _calculateFinalScore();
        Future.delayed(const Duration(milliseconds: 500), () {
          _endGame(true);
        });
      }
    });
  }

  void _animateSlide(int fromIndex, int toIndex, VoidCallback onComplete) {
    _slidingTileIndex = fromIndex;
    
    // Calculate slide direction
    final fromRow = fromIndex ~/ _gridSize;
    final fromCol = fromIndex % _gridSize;
    final toRow = toIndex ~/ _gridSize;
    final toCol = toIndex % _gridSize;
    
    final deltaX = (toCol - fromCol).toDouble();
    final deltaY = (toRow - fromRow).toDouble();
    
    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(deltaX, deltaY),
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeInOut,
    ));

    _slideController.forward().then((_) {
      _slideController.reset();
      _slidingTileIndex = null;
      onComplete();
    });
  }

  void _swapTiles(int index1, int index2) {
    final temp = _tiles[index1];
    _tiles[index1] = _tiles[index2];
    _tiles[index2] = temp;
  }

  bool _isPuzzleSolved() {
    for (int i = 0; i < _tiles.length - 1; i++) {
      if (_tiles[i].value != i + 1) {
        return false;
      }
    }
    return _tiles.last.isEmpty; // Last tile should be empty
  }

  int _calculateFinalScore() {
    int baseScore = (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.easy 
        ? 100 
        : (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.medium 
            ? 200 
            : 300;
    
    // Efficiency bonus (fewer moves = higher score)
    final optimalMoves = (_gridSize * _gridSize) * 2; // Rough estimate
    int efficiencyBonus = 0;
    if (_moves <= optimalMoves) {
      efficiencyBonus = ((optimalMoves - _moves) / optimalMoves * 50).round();
    }
    
    // Time bonus
    final timeLimit = widget.config?.timeLimit ?? 60;
    final remainingTime = timeLimit - _timerController.value * timeLimit;
    final timeBonus = (remainingTime / timeLimit * 100).round();
    
    // Perfect game bonus
    int perfectBonus = 0;
    if (_wrongAttempts == 0 && _moves <= optimalMoves) {
      perfectBonus = 100;
    }
    
    return baseScore + efficiencyBonus + timeBonus + perfectBonus;
  }

  void _endGame(bool success) {
    if (_isGameComplete) return;
    
    _isGameComplete = true;
    _timerController.stop();

    final timeTaken = _startTime != null 
        ? DateTime.now().difference(_startTime!) 
        : Duration.zero;

    final result = GameResult(
      isSuccess: success,
      score: _score,
      timeTaken: timeTaken,
      attempts: _wrongAttempts + 1,
    );

    widget.onGameComplete?.call(result);
  }

  void _showHint() {
    if (!(widget.config?.enableHints ?? false)) return;
    
    // Find the first tile that's not in the correct position
    for (int i = 0; i < _tiles.length - 1; i++) {
      if (!_tiles[i].isInCorrectPosition) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Try moving tile ${_tiles[i].value} towards its correct position'),
            duration: const Duration(seconds: 3),
            backgroundColor: Colors.blue,
          ),
        );
        break;
      }
    }
  }

  @override
  void dispose() {
    _timerController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Puzzle Solve'),
        automaticallyImplyLeading: false,
        actions: [
          if (widget.config?.enableHints ?? false)
            IconButton(
              icon: const Icon(Icons.lightbulb_outline),
              onPressed: _showHint,
            ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                'Score: $_score',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Progress indicators
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(
                    value: _timerController.value,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _timerController.value > 0.7 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Text('${_gridSize}x$_gridSize puzzle'),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Game stats
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatCard('Moves', _moves.toString(), Icons.touch_app),
                _buildStatCard('Errors', _wrongAttempts.toString(), Icons.error_outline),
                if (_isSolved)
                  _buildStatCard('Solved!', '🎉', Icons.celebration),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Puzzle grid
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: _buildPuzzleGrid(),
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Instructions
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Text(
                      _isSolved 
                          ? 'Puzzle solved! Well done!' 
                          : 'Tap numbered tiles to slide them into the empty space',
                      style: Theme.of(context).textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                    if ((widget.config?.enableHints ?? false) && !_isSolved) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Tip: Arrange numbers 1-${_gridSize * _gridSize - 1} in order',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 4),
            Text(
              value,
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPuzzleGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _gridSize,
        childAspectRatio: 1,
        crossAxisSpacing: 4,
        mainAxisSpacing: 4,
      ),
      itemCount: _tiles.length,
      itemBuilder: (context, index) {
        return _buildPuzzleTile(index);
      },
    );
  }

  Widget _buildPuzzleTile(int index) {
    final tile = _tiles[index];
    final isSliding = _slidingTileIndex == index;
    
    if (tile.isEmpty) {
      return Container(
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[300]!),
        ),
      );
    }

    Widget tileWidget = GestureDetector(
      onTap: () => _onTileTapped(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: tile.isInCorrectPosition 
              ? Colors.green[100] 
              : _isSolved 
                  ? Colors.blue[100]
                  : Colors.white,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: tile.isInCorrectPosition 
                ? Colors.green 
                : _isSolved 
                    ? Colors.blue
                    : Colors.grey[400]!,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(
          child: Text(
            tile.value.toString(),
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
              color: tile.isInCorrectPosition 
                  ? Colors.green[700]
                  : _isSolved 
                      ? Colors.blue[700]
                      : Colors.black87,
            ),
          ),
        ),
      ),
    );

    if (isSliding) {
      return AnimatedBuilder(
        animation: _slideAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(
              _slideAnimation.value.dx * (MediaQuery.of(context).size.width / _gridSize - 4),
              _slideAnimation.value.dy * (MediaQuery.of(context).size.width / _gridSize - 4),
            ),
            child: tileWidget,
          );
        },
      );
    }

    return tileWidget;
  }
  
  void _completeGame(bool success) {
    if (widget.isPracticeMode) {
      _showResultDialog(success);
    } else {
      if (widget.onGameResult != null) {
        widget.onGameResult!(success, _score);
      } else if (widget.onGameComplete != null) {
        final result = GameResult(
          isSuccess: success,
          score: _score,
          timeTaken: DateTime.now().difference(_startTime!),
          attempts: _wrongAttempts + 1,
        );
        widget.onGameComplete?.call(result);
      }
    }
  }
  
  void _showResultDialog(bool success) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(success ? 'Puzzle Solved!' : 'Try Again!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              success ? Icons.check_circle : Icons.cancel,
              size: 64,
              color: success ? Colors.green : Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              success 
                  ? 'You solved the sliding puzzle!'
                  : 'Keep practicing to improve your puzzle skills!',
            ),
            const SizedBox(height: 8),
            Text('Score: $_score'),
            const SizedBox(height: 8),
            Text('Moves: $_moves'),
            if (!success && _wrongAttempts > 0) ...[
              const SizedBox(height: 8),
              Text('Wrong attempts: $_wrongAttempts'),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Close game screen
            },
            child: const Text('Done'),
          ),
          if (!success)
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Reset game
                _initializeGame();
              },
              child: const Text('Try Again'),
            ),
        ],
      ),
    );
  }
}
