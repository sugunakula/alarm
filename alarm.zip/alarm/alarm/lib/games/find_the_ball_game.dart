import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';

class FindTheBallGame extends StatefulWidget {
  final GameConfig? config;
  final Function(GameResult)? onGameComplete;
  final Function(bool, int)? onGameResult;
  final bool isPracticeMode;

  const FindTheBallGame({
    super.key,
    this.config,
    this.onGameComplete,
    this.onGameResult,
    this.isPracticeMode = false,
  });

  @override
  State<FindTheBallGame> createState() => _FindTheBallGameState();
}

class _FindTheBallGameState extends State<FindTheBallGame>
    with TickerProviderStateMixin {
  late AnimationController _timerController;
  late AnimationController _shuffleController;
  late AnimationController _revealController;
  late List<AnimationController> _cupControllers;
  late List<Animation<Offset>> _cupAnimations;

  int _ballPosition = 0;
  int _numberOfCups = 3;
  int? _selectedCup;
  bool _isShuffling = false;
  bool _showBall = true;
  bool _gameStarted = false;
  bool _isGameComplete = false;
  int _currentRound = 1;
  int _totalRounds = 5;
  int _score = 0;
  int _wrongAttempts = 0;
  DateTime? _startTime;

  final Random _random = Random();

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeGame();
  }

  void _initializeAnimations() {
    _timerController = AnimationController(
      duration: Duration(seconds: widget.config.timeLimit),
      vsync: this,
    );

    _shuffleController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    );

    _revealController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _cupControllers = List.generate(_numberOfCups, (index) {
      return AnimationController(
        duration: const Duration(milliseconds: 800),
        vsync: this,
      );
    });

    _updateCupAnimations();

    _timerController.addListener(() {
      if (_timerController.isCompleted && !_isGameComplete) {
        _endGame(false);
      }
    });
  }

  void _updateCupAnimations() {
    _cupAnimations = _cupControllers.map((controller) {
      return Tween<Offset>(
        begin: Offset.zero,
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: controller,
        curve: Curves.easeInOut,
      ));
    }).toList();
  }

  void _initializeGame() {
    _startTime = DateTime.now();
    _timerController.forward();
    _resetRound();
  }

  void _resetRound() {
    setState(() {
      _ballPosition = _random.nextInt(_numberOfCups);
      _selectedCup = null;
      _showBall = true;
      _gameStarted = false;
      
      // Increase difficulty by adding more cups
      if (widget.config.difficulty == GameDifficulty.medium) {
        _numberOfCups = 4;
      } else if (widget.config.difficulty == GameDifficulty.hard) {
        _numberOfCups = 5;
      }
    });

    // Show ball initially, then hide and shuffle
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _showBall = false;
        _gameStarted = true;
      });
      _startShuffling();
    });
  }

  void _startShuffling() {
    setState(() {
      _isShuffling = true;
    });

    final shuffleCount = widget.config.difficulty == GameDifficulty.easy 
        ? 3 
        : widget.config.difficulty == GameDifficulty.medium 
            ? 5 
            : 8;

    _performShuffle(shuffleCount);
  }

  void _performShuffle(int remainingShuffles) {
    if (remainingShuffles <= 0) {
      setState(() {
        _isShuffling = false;
      });
      return;
    }

    // Pick two random cups to swap
    final cup1 = _random.nextInt(_numberOfCups);
    int cup2;
    do {
      cup2 = _random.nextInt(_numberOfCups);
    } while (cup2 == cup1);

    // Update ball position if it's being moved
    if (_ballPosition == cup1) {
      _ballPosition = cup2;
    } else if (_ballPosition == cup2) {
      _ballPosition = cup1;
    }

    // Animate the swap
    _animateSwap(cup1, cup2, () {
      _performShuffle(remainingShuffles - 1);
    });
  }

  void _animateSwap(int cup1, int cup2, VoidCallback onComplete) {
    final distance = (cup2 - cup1).abs() * 0.3;
    final direction1 = cup2 > cup1 ? distance : -distance;
    final direction2 = -direction1;

    // Set up animations for both cups
    _cupAnimations[cup1] = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(direction1, 0),
    ).animate(CurvedAnimation(
      parent: _cupControllers[cup1],
      curve: Curves.easeInOut,
    ));

    _cupAnimations[cup2] = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(direction2, 0),
    ).animate(CurvedAnimation(
      parent: _cupControllers[cup2],
      curve: Curves.easeInOut,
    ));

    // Start animations
    _cupControllers[cup1].forward().then((_) {
      _cupControllers[cup1].reverse();
    });
    
    _cupControllers[cup2].forward().then((_) {
      _cupControllers[cup2].reverse().then((_) {
        onComplete();
      });
    });
  }

  void _selectCup(int cupIndex) {
    if (_isShuffling || _selectedCup != null || !_gameStarted) return;

    setState(() {
      _selectedCup = cupIndex;
      _showBall = true;
    });

    _revealController.forward();

    // Delay to show result
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (cupIndex == _ballPosition) {
        _handleCorrectGuess();
      } else {
        _handleWrongGuess();
      }
    });
  }

  void _handleCorrectGuess() {
    final roundScore = _calculateRoundScore();
    _score += roundScore;
    _currentRound++;

    if (_currentRound > _totalRounds) {
      _endGame(true);
    } else {
      Future.delayed(const Duration(milliseconds: 1000), () {
        _revealController.reset();
        _resetRound();
      });
    }
  }

  void _handleWrongGuess() {
    _wrongAttempts++;
    
    if (_wrongAttempts >= widget.config.maxAttempts) {
      _endGame(false);
    } else {
      Future.delayed(const Duration(milliseconds: 1500), () {
        _revealController.reset();
        _resetRound();
      });
    }
  }

  int _calculateRoundScore() {
    int baseScore = widget.config.difficulty == GameDifficulty.easy 
        ? 20 
        : widget.config.difficulty == GameDifficulty.medium 
            ? 30 
            : 50;
    
    // Bonus for remaining time
    final remainingTime = widget.config.timeLimit - _timerController.value * widget.config.timeLimit;
    final timeBonus = (remainingTime / widget.config.timeLimit * 15).round();
    
    return baseScore + timeBonus;
  }

  void _endGame(bool success) {
    if (_isGameComplete) return;
    
    _isGameComplete = true;
    _timerController.stop();

    final timeTaken = _startTime != null 
        ? DateTime.now().difference(_startTime!) 
        : Duration.zero;

    final result = GameResult(
      isSuccess: success,
      score: _score,
      timeTaken: timeTaken,
      attempts: _wrongAttempts + 1,
    );

    widget.onGameComplete(result);
  }

  @override
  void dispose() {
    _timerController.dispose();
    _shuffleController.dispose();
    _revealController.dispose();
    for (var controller in _cupControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Find The Ball'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                'Score: $_score',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Progress indicators
            Row(
              children: [
                Expanded(
                  child: LinearProgressIndicator(
                    value: _timerController.value,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _timerController.value > 0.7 
                          ? Colors.red 
                          : Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Text('Round $_currentRound/$_totalRounds'),
              ],
            ),
            
            const SizedBox(height: 32),
            
            // Instructions
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Icon(
                      Icons.sports_baseball,
                      size: 48,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _getInstructionText(),
                      style: Theme.of(context).textTheme.titleMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 40),
            
            // Game area
            Expanded(
              child: Center(
                child: _buildGameArea(),
              ),
            ),
            
            // Attempts remaining
            if (_wrongAttempts > 0) ...[
              const SizedBox(height: 16),
              Text(
                'Wrong attempts: $_wrongAttempts/${widget.config?.maxAttempts ?? 3}',
                style: TextStyle(
                  color: Colors.red[700],
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _getInstructionText() {
    if (!_gameStarted) {
      return _showBall 
          ? 'Remember where the ball is!' 
          : 'Watch the cups shuffle...';
    }
    if (_isShuffling) {
      return 'Keep your eyes on the ball!';
    }
    if (_selectedCup != null) {
      return _selectedCup == _ballPosition 
          ? 'Correct! Well done!' 
          : 'Wrong cup! Try again.';
    }
    return 'Which cup has the ball?';
  }

  Widget _buildGameArea() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Cups
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(_numberOfCups, (index) {
            return _buildCup(index);
          }),
        ),
        
        const SizedBox(height: 20),
        
        // Ball (shown when revealing or initially)
        if (_showBall || _selectedCup != null) ...[
          const SizedBox(height: 40),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(_numberOfCups, (index) {
              return SizedBox(
                width: 60,
                height: 40,
                child: Center(
                  child: index == _ballPosition && (_showBall || _selectedCup != null)
                      ? AnimatedBuilder(
                          animation: _revealController,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _showBall ? 1.0 : _revealController.value,
                              child: Container(
                                width: 20,
                                height: 20,
                                decoration: const BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            );
                          },
                        )
                      : null,
                ),
              );
            }),
          ),
        ],
      ],
    );
  }

  Widget _buildCup(int index) {
    final isSelected = _selectedCup == index;
    final hasWrongSelection = _selectedCup != null && _selectedCup != _ballPosition;
    final isWrongCup = hasWrongSelection && isSelected;
    final isCorrectCup = _selectedCup != null && index == _ballPosition;
    
    Color cupColor = Colors.brown[600]!;
    if (isCorrectCup) {
      cupColor = Colors.green[600]!;
    } else if (isWrongCup) {
      cupColor = Colors.red[600]!;
    }

    return AnimatedBuilder(
      animation: _cupAnimations[index],
      builder: (context, child) {
        return Transform.translate(
          offset: _cupAnimations[index].value * 100,
          child: GestureDetector(
            onTap: () => _selectCup(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: 60,
              height: 80,
              decoration: BoxDecoration(
                color: cupColor,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
                border: Border.all(
                  color: isSelected ? Colors.white : Colors.brown[800]!,
                  width: isSelected ? 3 : 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
  
  void _completeGame(bool success) {
    if (widget.isPracticeMode) {
      _showResultDialog(success);
    } else {
      if (widget.onGameResult != null) {
        widget.onGameResult!(success, _currentScore);
      } else if (widget.onGameComplete != null) {
        final result = GameResult(
          gameType: GameType.findTheBall,
          success: success,
          score: _currentScore,
          timeTaken: DateTime.now().difference(_startTime).inSeconds,
          attempts: _wrongAttempts + 1,
        );
        widget.onGameComplete!(result);
      }
    }
  }
  
  void _showResultDialog(bool success) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(success ? 'Great Job!' : 'Try Again!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              success ? Icons.check_circle : Icons.cancel,
              size: 64,
              color: success ? Colors.green : Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              success 
                  ? 'You found the ball successfully!'
                  : 'Keep practicing to improve your tracking skills!',
            ),
            const SizedBox(height: 8),
            Text('Score: $_currentScore'),
            if (!success) ...[
              const SizedBox(height: 8),
              Text('Wrong attempts: $_wrongAttempts'),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Close game screen
            },
            child: const Text('Done'),
          ),
          if (!success)
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Reset game
                _resetRound();
              },
              child: const Text('Try Again'),
            ),
        ],
      ),
    );
  }
}
