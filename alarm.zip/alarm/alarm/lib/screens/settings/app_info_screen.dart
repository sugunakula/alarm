import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../utils/constants.dart';
import '../../utils/theme.dart';

class AppInfoScreen extends StatelessWidget {
  const AppInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About NoSnooz'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // App Logo and Info
            _buildAppHeader(context),
            
            const SizedBox(height: 32),
            
            // Key Features
            _buildSection(
              context,
              'Key Features',
              Icons.star,
              AppColors.premiumGold,
              [
                'Game-based alarm dismissal system',
                '5 engaging mini-games to prevent snoozing',
                'Adaptive difficulty that scales with performance',
                'Comprehensive alarm scheduling options',
                'Premium sounds and customization',
                'Smart statistics and progress tracking',
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Technical Information
            _buildSection(
              context,
              'Technical Information',
              Icons.info_outline,
              Theme.of(context).colorScheme.primary,
              [
                'Built with Flutter for cross-platform compatibility',
                'Uses advanced alarm scheduling APIs',
                'Local data storage for privacy',
                'Optimized for performance and battery life',
                'Regular updates and improvements',
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Developer Information
            _buildDeveloperSection(context),
            
            const SizedBox(height: 24),
            
            // Version Information
            _buildVersionInfo(context),
            
            const SizedBox(height: 32),
            
            // Action Buttons
            _buildActionButtons(context),
          ],
        ),
      ),
    );
  }

  Widget _buildAppHeader(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(60),
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: SvgPicture.asset(
            AppConstants.logoPath,
            width: 120,
            height: 120,
          ),
        ),
        const SizedBox(height: 16),
        Text(
          AppConstants.appName,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          AppConstants.appTagline,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
          ),
        ),
      ],
    );
  }

  Widget _buildSection(
    BuildContext context,
    String title,
    IconData icon,
    Color color,
    List<String> items,
  ) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...items.map((item) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    margin: const EdgeInsets.only(top: 8, right: 12),
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      item,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildDeveloperSection(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.code, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 12),
                Text(
                  'Development',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'NoSnooz is crafted with passion to help people build better morning routines. '
              'Our mission is to make waking up an engaging and positive experience through '
              'thoughtfully designed games and reliable alarm technology.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            _buildInfoRow(context, 'Framework', 'Flutter & Dart'),
            _buildInfoRow(context, 'Platform', 'iOS & Android'),
            _buildInfoRow(context, 'Architecture', 'MVVM with Provider'),
            _buildInfoRow(context, 'Storage', 'Local (SharedPreferences)'),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              '$label:',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVersionInfo(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.info, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 12),
                Text(
                  'Version Information',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _buildInfoRow(context, 'Version', AppConstants.appVersion),
            _buildInfoRow(context, 'Build', 'Release'),
            _buildInfoRow(context, 'Last Updated', 'August 2025'),
            _buildInfoRow(context, 'Compatibility', 'iOS 12.0+ | Android 6.0+'),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => _shareApp(context),
            icon: const Icon(Icons.share),
            label: const Text('Share NoSnooz'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _showLicenses(context),
                icon: const Icon(Icons.description),
                label: const Text('Licenses'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => _copyVersion(context),
                icon: const Icon(Icons.copy),
                label: const Text('Copy Info'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Text(
          '© 2025 NoSnooz. All rights reserved.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          'Made with ❤️ for better mornings',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  void _shareApp(BuildContext context) {
    const message = 'Check out NoSnooz - the alarm clock that prevents snoozing through fun mini-games! 🎮⏰';
    
    // Simulate sharing
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Share functionality would open system share sheet'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _showLicenses(BuildContext context) {
    showLicensePage(
      context: context,
      applicationName: AppConstants.appName,
      applicationVersion: AppConstants.appVersion,
      applicationIcon: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Theme.of(context).colorScheme.primary,
              AppColors.premiumGold,
            ],
          ),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Icon(
          Icons.alarm,
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }

  void _copyVersion(BuildContext context) {
    final info = '''
${AppConstants.appName} ${AppConstants.appVersion}
${AppConstants.appTagline}

Platform: Flutter
Architecture: MVVM with Provider
Storage: Local (SharedPreferences)
Games: 5 mini-games implemented
Features: Game-based dismissal, Premium sounds, Statistics
''';

    Clipboard.setData(ClipboardData(text: info));
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('App information copied to clipboard'),
        duration: Duration(seconds: 2),
      ),
    );
  }
}
