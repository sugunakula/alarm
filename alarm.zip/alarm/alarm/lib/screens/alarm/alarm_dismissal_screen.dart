import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:vibration/vibration.dart';
import 'package:alarm/alarm.dart';
import '../../providers/alarm_provider.dart';
import '../../providers/game_provider.dart';
import '../../models/alarm_model.dart';
import '../../models/game_model.dart';
import '../../games/math_equation_game.dart';
import '../../games/find_the_ball_game.dart';
import '../../games/color_match_blitz_game.dart';
import '../../games/memory_flip_game.dart';
import '../../games/puzzle_solve_game.dart';
import '../../services/alarm_service.dart';
import '../../utils/theme.dart';
import '../main_navigation.dart';

class AlarmDismissalScreen extends StatefulWidget {
  const AlarmDismissalScreen({super.key});

  @override
  State<AlarmDismissalScreen> createState() => _AlarmDismissalScreenState();
}

class _AlarmDismissalScreenState extends State<AlarmDismissalScreen>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _backgroundController;
  late Animation<Color?> _backgroundAnimation;

  AlarmModel? _currentAlarm;
  bool _gameStarted = false;
  int _gameAttempts = 0;
  final int _maxGameAttempts = 3;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadCurrentAlarm();
    _startVibration();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 0.95,
      end: 1.05,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _backgroundController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _backgroundAnimation = ColorTween(
      begin: Colors.red[600],
      end: Colors.red[800],
    ).animate(CurvedAnimation(
      parent: _backgroundController,
      curve: Curves.easeInOut,
    ));

    _pulseController.repeat(reverse: true);
    _backgroundController.repeat(reverse: true);
  }

  void _loadCurrentAlarm() {
    final alarmProvider = context.read<AlarmProvider>();
    _currentAlarm = alarmProvider.ringingAlarm;
  }

  void _startVibration() {
    if (_currentAlarm?.vibrate == true) {
      _vibratePattern();
    }
  }

  void _vibratePattern() async {
    if (await Vibration.hasVibrator() == true) {
      Vibration.vibrate(
        pattern: [500, 1000, 500, 1000],
        repeat: 0,
      );
    }
  }

  void _stopVibration() {
    Vibration.cancel();
  }

  void _startGame() {
    if (_currentAlarm == null) return;

    final gameProvider = context.read<GameProvider>();
    
    // Get the game type from the alarm
    GameType gameType = _currentAlarm!.gameType;

    final config = gameProvider.getGameConfig(gameType);
    
    setState(() {
      _gameStarted = true;
    });

    gameProvider.startGame(gameType, config: config);
  }

  Timer? _vibrationTimer;

  void _onGameComplete(GameResult result) {
    final gameProvider = context.read<GameProvider>();
    
    gameProvider.completeGame(result);
    
    if (result.isSuccess) {
      // Game completed successfully - dismiss alarm
      _dismissAlarm();
    } else {
      // Game failed - allow retry or force dismiss after max attempts
      _gameAttempts++;
      if (_gameAttempts >= _maxGameAttempts) {
        _showForceSnoozeDialog();
      } else {
        setState(() {
          _gameStarted = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Try again! Attempt $_gameAttempts of $_maxGameAttempts'),
            backgroundColor: Colors.orange,
          ),
        );
      }
    }
  }

  void _dismissAlarm() {
    _stopVibration();
    
    final alarmProvider = context.read<AlarmProvider>();
    if (_currentAlarm != null) {
      alarmProvider.dismissAlarm(_currentAlarm!.id);
    }

    // Reset alarm service state
    AlarmService.onAlarmDismissed();

    // Navigate back to main app
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const MainNavigation()),
      (route) => false,
    );
    
    // Show success message after navigation
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Alarm dismissed! Good morning! 🌅'),
            backgroundColor: AppColors.successGreen,
          ),
        );
      }
    });
  }

  void _showGameFailedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Game Failed'),
        content: Text(
          'You failed to complete the game. You have ${_maxGameAttempts - _gameAttempts} attempts remaining.\\n\\nTry again to dismiss your alarm!',
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _startGame();
            },
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }

  void _showForceSnoozeDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Maximum Attempts Reached'),
        content: const Text(
          'You have failed the game 3 times. You can either:\\n\\n'
          '• Try the game one more time\\n'
          '• Force dismiss the alarm (not recommended)',
        ),
        actions: [
          TextButton(
            onPressed: _forceDismiss,
            child: const Text('Force Dismiss'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _gameAttempts = 0; // Reset attempts for final try
              _startGame();
            },
            child: const Text('Final Attempt'),
          ),
        ],
      ),
    );
  }

  void _forceDismiss() {
    Navigator.of(context).pop(); // Close dialog
    _dismissAlarm();
  }

  Widget _buildGameScreen() {
    final gameProvider = context.read<GameProvider>();
    final config = gameProvider.currentConfig;
    final gameType = gameProvider.currentGame;

    if (gameType == null) {
      return const Scaffold(
        body: Center(
          child: Text('No game selected'),
        ),
      );
    }

    switch (gameType) {
      case GameType.mathEquation:
        return MathEquationGame(
          config: config,
          onGameComplete: _onGameComplete,
        );
      case GameType.findTheBall:
        return FindTheBallGame(
          config: config,
          onGameComplete: _onGameComplete,
        );
      case GameType.colorMatchBlitz:
        return ColorMatchBlitzGame(
          config: config,
          onGameComplete: _onGameComplete,
        );
      case GameType.memoryFlip:
        return MemoryFlipGame(
          config: config,
          onGameComplete: _onGameComplete,
        );
      case GameType.puzzleSolve:
        return PuzzleSolveGame(
          config: config,
          onGameComplete: _onGameComplete,
        );
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _backgroundController.dispose();
    _stopVibration();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_gameStarted && _currentAlarm != null) {
      return _buildGameScreen();
    }

    return AnimatedBuilder(
      animation: _backgroundAnimation,
      builder: (context, child) {
        return Scaffold(
          backgroundColor: _backgroundAnimation.value,
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Header
                  _buildHeader(),
                  
                  const Spacer(),
                  
                  // Main alarm display
                  _buildAlarmDisplay(),
                  
                  const Spacer(),
                  
                  // Dismiss button
                  _buildDismissButton(),
                  
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Text(
          'ALARM',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
        if (_gameAttempts > 0)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              'Attempts: $_gameAttempts/$_maxGameAttempts',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildAlarmDisplay() {
    if (_currentAlarm == null) {
      return const Center(
        child: Text(
          'No active alarm',
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: Column(
            children: [
              // Time display
              Text(
                TimeOfDay.fromDateTime(_currentAlarm!.dateTime).format(context),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 72,
                  fontWeight: FontWeight.w300,
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Alarm label
              if (_currentAlarm!.label.isNotEmpty) ...[
                Text(
                  _currentAlarm!.label,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
              ],
              
              // Game badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.games,
                      color: Colors.white,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Game: ${_getGameName(_currentAlarm!.gameType)}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 16),
              
              const Text(
                'Complete the mini-game to dismiss',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDismissButton() {
    return SizedBox(
      width: double.infinity,
      height: 60,
      child: ElevatedButton(
        onPressed: _startGame,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.red[700],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          elevation: 8,
        ),
        child: const Text(
          'DISMISS ALARM',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }

  String _getGameName(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return 'Math';
      case GameType.findTheBall:
        return 'Find Ball';
      case GameType.puzzleSolve:
        return 'Puzzle';
      case GameType.colorMatchBlitz:
        return 'Color Match';
      case GameType.memoryFlip:
        return 'Memory';
    }
  }

  void _showMaxAttemptsDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Max Attempts Reached'),
        content: const Text(
          'You have reached the maximum number of attempts. The alarm will be dismissed, but this might affect your wake-up effectiveness.',
        ),
        actions: [
          TextButton(
            onPressed: _dismissAlarm,
            child: const Text('Dismiss Anyway'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {
                _gameAttempts = 0;
                _gameStarted = false;
              });
            },
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }
}
