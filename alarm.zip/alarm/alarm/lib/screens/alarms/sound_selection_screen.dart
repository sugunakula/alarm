import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/sound_model.dart';
import '../../providers/subscription_provider.dart';
import '../../utils/theme.dart';
import '../subscription/subscription_screen.dart';

class SoundSelectionScreen extends StatefulWidget {
  final String? currentSoundId;
  final Function(AlarmSound) onSoundSelected;

  const SoundSelectionScreen({
    super.key,
    this.currentSoundId,
    required this.onSoundSelected,
  });

  @override
  State<SoundSelectionScreen> createState() => _SoundSelectionScreenState();
}

class _SoundSelectionScreenState extends State<SoundSelectionScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? _playingSoundId;
  bool _isPlaying = false;

  final List<SoundCategory> _categories = [
    SoundCategory.classic,
    SoundCategory.nature,
    SoundCategory.music,
    SoundCategory.voice,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    
    // Removed audio player initialization since we don't have actual audio files
  }

  @override
  void dispose() {
    _tabController.dispose();
    // No audio resources to dispose
    super.dispose();
  }

  Future<void> _playSound(AlarmSound sound) async {
    if (_playingSoundId == sound.id && _isPlaying) {
      // Stop current sound simulation
      setState(() {
        _playingSoundId = null;
        _isPlaying = false;
      });
    } else {
      // Stop any current sound and start new one
      setState(() {
        _playingSoundId = sound.id;
        _isPlaying = true;
      });
      
      // Show preview message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Preview: ${sound.name}'),
          duration: const Duration(seconds: 2),
        ),
      );
      
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted && _playingSoundId == sound.id) {
          setState(() {
            _playingSoundId = null;
            _isPlaying = false;
          });
        }
      });
    }
  }

  void _selectSound(AlarmSound sound) {
    widget.onSoundSelected(sound);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Alarm Sound'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: _categories.map((category) {
            return Tab(
              icon: Icon(SoundManager.getCategoryIcon(category)),
              text: SoundManager.getCategoryName(category),
            );
          }).toList(),
        ),
      ),
      body: Consumer<SubscriptionProvider>(
        builder: (context, subscriptionProvider, child) {
          return TabBarView(
            controller: _tabController,
            children: _categories.map((category) {
              return _buildCategoryTab(category, subscriptionProvider);
            }).toList(),
          );
        },
      ),
    );
  }

  Widget _buildCategoryTab(SoundCategory category, SubscriptionProvider subscriptionProvider) {
    final sounds = SoundManager.getSoundsByCategory(category);
    
    if (sounds.isEmpty) {
      return const Center(
        child: Text('No sounds available in this category'),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sounds.length,
      itemBuilder: (context, index) {
        final sound = sounds[index];
        final isLocked = sound.isPremium && !subscriptionProvider.isPremium;
        final isSelected = sound.id == widget.currentSoundId;
        final isPlaying = _playingSoundId == sound.id && _isPlaying;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: SoundManager.getCategoryColor(category).withOpacity(0.2),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Icon(
                      sound.icon,
                      color: isLocked ? Colors.grey : SoundManager.getCategoryColor(category),
                    ),
                  ),
                  if (isLocked)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: AppColors.premiumGold,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.lock,
                          size: 10,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            title: Text(
              sound.name,
              style: TextStyle(
                color: isLocked ? Colors.grey : null,
                fontWeight: isSelected ? FontWeight.bold : null,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sound.description,
                  style: TextStyle(
                    color: isLocked ? Colors.grey : null,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.timer,
                      size: 14,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${sound.duration.inSeconds}s',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    if (sound.isPremium) ...[
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.premiumGold.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'PREMIUM',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: AppColors.premiumGold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Play/Stop button
                IconButton(
                  icon: Icon(
                    isPlaying ? Icons.stop : Icons.play_arrow,
                    color: isLocked ? Colors.grey : Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: isLocked ? null : () => _playSound(sound),
                ),
                // Select button or lock icon
                if (isLocked)
                  IconButton(
                    icon: Icon(
                      Icons.lock,
                      color: AppColors.premiumGold,
                    ),
                    onPressed: () => _showPremiumDialog(),
                  )
                else
                  IconButton(
                    icon: Icon(
                      isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                      color: isSelected 
                          ? Colors.green 
                          : Theme.of(context).colorScheme.primary,
                    ),
                    onPressed: () => _selectSound(sound),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showPremiumDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.star,
              color: AppColors.premiumGold,
            ),
            const SizedBox(width: 8),
            const Text('Premium Sound'),
          ],
        ),
        content: const Text(
          'This sound is available for premium subscribers only. Upgrade to unlock all premium sounds and features!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const SubscriptionScreen(),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.premiumGold,
              foregroundColor: Colors.white,
            ),
            child: const Text('Upgrade'),
          ),
        ],
      ),
    );
  }
}
