import 'package:flutter/material.dart';
import '../../models/sound_model.dart';
import '../../utils/theme.dart';

class SoundSelectionScreen extends StatefulWidget {
  final String? currentSoundId;
  final Function(AlarmSound) onSoundSelected;

  const SoundSelectionScreen({
    super.key,
    this.currentSoundId,
    required this.onSoundSelected,
  });

  @override
  State<SoundSelectionScreen> createState() => _SoundSelectionScreenState();
}

class _SoundSelectionScreenState extends State<SoundSelectionScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? _playingSoundId;
  bool _isPlaying = false;

  final List<SoundCategory> _categories = [
    SoundCategory.classic,
    SoundCategory.nature,
    SoundCategory.music,
    SoundCategory.voice,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    
    // Removed audio player initialization since we don't have actual audio files
  }

  @override
  void dispose() {
    _tabController.dispose();
    // No audio resources to dispose
    super.dispose();
  }

  Future<void> _playSound(AlarmSound sound) async {
    if (_playingSoundId == sound.id && _isPlaying) {
      // Stop current sound simulation
      setState(() {
        _playingSoundId = null;
        _isPlaying = false;
      });
    } else {
      // Stop any current sound and start new one
      setState(() {
        _playingSoundId = sound.id;
        _isPlaying = true;
      });
      
      // Show preview message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Preview: ${sound.name}'),
          duration: const Duration(seconds: 2),
        ),
      );
      
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted && _playingSoundId == sound.id) {
          setState(() {
            _playingSoundId = null;
            _isPlaying = false;
          });
        }
      });
    }
  }

  void _selectSound(AlarmSound sound) {
    widget.onSoundSelected(sound);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Alarm Sound'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: _categories.map((category) {
            return Tab(
              icon: Icon(SoundManager.getCategoryIcon(category)),
              text: SoundManager.getCategoryName(category),
            );
          }).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _categories.map((category) {
          return _buildCategoryTab(category);
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryTab(SoundCategory category) {
    final sounds = SoundManager.getSoundsByCategory(category);
    
    if (sounds.isEmpty) {
      return const Center(
        child: Text('No sounds available in this category'),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sounds.length,
      itemBuilder: (context, index) {
        final sound = sounds[index];
        final isSelected = sound.id == widget.currentSoundId;
        final isPlaying = _playingSoundId == sound.id && _isPlaying;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: SoundManager.getCategoryColor(category).withOpacity(0.2),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Center(
                child: Icon(
                  sound.icon,
                  color: SoundManager.getCategoryColor(category),
                ),
              ),
            ),
            title: Text(
              sound.name,
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.bold : null,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sound.description,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.timer,
                      size: 14,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${sound.duration.inSeconds}s',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    // No premium badges
                  ],
                ),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Play/Stop button
                IconButton(
                  icon: Icon(
                    isPlaying ? Icons.stop : Icons.play_arrow,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () => _playSound(sound),
                ),
                // Select button
                IconButton(
                  icon: Icon(
                    isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                    color: isSelected 
                        ? Colors.green 
                        : Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () => _selectSound(sound),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Premium functionality removed
}
