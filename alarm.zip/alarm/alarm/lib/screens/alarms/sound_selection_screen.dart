import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/sound_model.dart';
import '../../utils/theme.dart';

class SoundSelectionScreen extends StatefulWidget {
  final String? currentSoundId;
  final Function(AlarmSound) onSoundSelected;

  const SoundSelectionScreen({
    super.key,
    this.currentSoundId,
    required this.onSoundSelected,
  });

  @override
  State<SoundSelectionScreen> createState() => _SoundSelectionScreenState();
}

class _SoundSelectionScreenState extends State<SoundSelectionScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  String? _playingSoundId;
  bool _isPlaying = false;
  late AudioPlayer _audioPlayer;
  List<AlarmSound> _customSounds = [];

  final List<SoundCategory> _categories = [
    SoundCategory.classic,
    SoundCategory.nature,
    SoundCategory.music,
    SoundCategory.voice,
    SoundCategory.custom,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _categories.length, vsync: this);
    _audioPlayer = AudioPlayer();
    _loadCustomSounds();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }
  
  Future<void> _loadCustomSounds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final customSoundsJson = prefs.getStringList('custom_sounds') ?? [];
      
      _customSounds = customSoundsJson.map((soundJson) {
        final data = jsonDecode(soundJson);
        return AlarmSound.fromJson(data);
      }).toList();
      
      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      debugPrint('Error loading custom sounds: $e');
    }
  }
  
  Future<void> _saveCustomSounds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final customSoundsJson = _customSounds.map((sound) => jsonEncode(sound.toJson())).toList();
      await prefs.setStringList('custom_sounds', customSoundsJson);
    } catch (e) {
      debugPrint('Error saving custom sounds: $e');
    }
  }

  Future<void> _playSound(AlarmSound sound) async {
    try {
      if (_playingSoundId == sound.id && _isPlaying) {
        // Stop current sound
        await _audioPlayer.stop();
        setState(() {
          _playingSoundId = null;
          _isPlaying = false;
        });
      } else {
        // Stop any current sound
        await _audioPlayer.stop();
        
        setState(() {
          _playingSoundId = sound.id;
          _isPlaying = true;
        });
        
        // Play the sound
        if (sound.category == SoundCategory.custom) {
          // Custom sound - file path
          await _audioPlayer.play(DeviceFileSource(sound.assetPath));
        } else {
          // Built-in sound - asset
          await _audioPlayer.play(AssetSource(sound.assetPath));
        }
        
        // Show preview message
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Playing: ${sound.name}'),
              duration: const Duration(seconds: 2),
              action: SnackBarAction(
                label: 'Stop',
                onPressed: () async {
                  await _audioPlayer.stop();
                  if (mounted) {
                    setState(() {
                      _playingSoundId = null;
                      _isPlaying = false;
                    });
                  }
                },
              ),
            ),
          );
        }
        
        // Auto-stop after 10 seconds
        Future.delayed(const Duration(seconds: 10), () async {
          if (mounted && _playingSoundId == sound.id) {
            await _audioPlayer.stop();
            setState(() {
              _playingSoundId = null;
              _isPlaying = false;
            });
          }
        });
      }
    } catch (e) {
      debugPrint('Error playing sound: $e');
      if (mounted) {
        setState(() {
          _playingSoundId = null;
          _isPlaying = false;
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not play ${sound.name}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _selectSound(AlarmSound sound) {
    widget.onSoundSelected(sound);
    Navigator.of(context).pop();
  }
  
  Future<void> _addCustomSound() async {
    try {
      // Request permission if needed
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        await Permission.storage.request();
      }
      
      // Pick audio file
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
      );
      
      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        if (file.path != null) {
          // Get app documents directory
          final appDir = await getApplicationDocumentsDirectory();
          final customSoundsDir = Directory('${appDir.path}/custom_sounds');
          if (!await customSoundsDir.exists()) {
            await customSoundsDir.create(recursive: true);
          }
          
          // Copy file to app directory
          final originalFile = File(file.path!);
          final fileName = file.name;
          final newPath = '${customSoundsDir.path}/$fileName';
          await originalFile.copy(newPath);
          
          // Create custom sound object
          final customSound = AlarmSound(
            id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
            name: fileName.split('.').first,
            description: 'Custom sound',
            assetPath: newPath,
            category: SoundCategory.custom,
            duration: const Duration(seconds: 30), // Default duration
            icon: Icons.audiotrack,
          );
          
          // Add to list and save
          _customSounds.add(customSound);
          await _saveCustomSounds();
          
          setState(() {});
          
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Added custom sound: ${customSound.name}'),
                backgroundColor: Colors.green,
              ),
            );
          }
        }
      }
    } catch (e) {
      debugPrint('Error adding custom sound: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error adding custom sound: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Alarm Sound'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabs: _categories.map((category) {
            return Tab(
              icon: Icon(SoundManager.getCategoryIcon(category)),
              text: SoundManager.getCategoryName(category),
            );
          }).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _categories.map((category) {
          return _buildCategoryTab(category);
        }).toList(),
      ),
    );
  }

  Widget _buildCategoryTab(SoundCategory category) {
    List<AlarmSound> sounds;
    
    if (category == SoundCategory.custom) {
      sounds = _customSounds;
    } else {
      sounds = SoundManager.getSoundsByCategory(category);
    }
    
    if (category == SoundCategory.custom) {
      return Scaffold(
        body: sounds.isEmpty
            ? const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.audiotrack,
                      size: 64,
                      color: Colors.grey,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'No custom sounds added',
                      style: TextStyle(
                        fontSize: 18,
                        color: Colors.grey,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Tap + to add your own sound files',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              )
            : _buildSoundsList(sounds),
        floatingActionButton: FloatingActionButton(
          onPressed: _addCustomSound,
          child: const Icon(Icons.add),
          tooltip: 'Add Custom Sound',
        ),
      );
    }
    
    if (sounds.isEmpty) {
      return const Center(
        child: Text('No sounds available in this category'),
      );
    }

    return _buildSoundsList(sounds);
  }
  
  Widget _buildSoundsList(List<AlarmSound> sounds) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: sounds.length,
      itemBuilder: (context, index) {
        final sound = sounds[index];
        final isSelected = sound.id == widget.currentSoundId;
        final isPlaying = _playingSoundId == sound.id && _isPlaying;

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: SoundManager.getCategoryColor(sound.category).withOpacity(0.2),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Center(
                child: Icon(
                  sound.icon,
                  color: SoundManager.getCategoryColor(sound.category),
                ),
              ),
            ),
            title: Text(
              sound.name,
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.bold : null,
              ),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  sound.description,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.timer,
                      size: 14,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${sound.duration.inSeconds}s',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                    // No premium badges
                  ],
                ),
              ],
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Play/Stop button
                IconButton(
                  icon: Icon(
                    isPlaying ? Icons.stop : Icons.play_arrow,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () => _playSound(sound),
                ),
                // Select button
                IconButton(
                  icon: Icon(
                    isSelected ? Icons.check_circle : Icons.radio_button_unchecked,
                    color: isSelected 
                        ? Colors.green 
                        : Theme.of(context).colorScheme.primary,
                  ),
                  onPressed: () => _selectSound(sound),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Premium functionality removed
}
