import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/alarm_provider.dart';
import '../../providers/game_provider.dart';
import '../../models/alarm_model.dart';
import '../../utils/theme.dart';

class EditAlarmScreen extends StatefulWidget {
  final AlarmModel alarm;
  
  const EditAlarmScreen({super.key, required this.alarm});

  @override
  State<EditAlarmScreen> createState() => _EditAlarmScreenState();
}

class _EditAlarmScreenState extends State<EditAlarmScreen> {
  late DateTime _selectedTime;
  late TextEditingController _labelController;
  late RepeatOption _selectedRepeat;
  late GameType _selectedGame;
  late bool _vibrate;
  late bool _enableLight;
  late List<int> _customDays;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _selectedTime = widget.alarm.dateTime;
    _labelController = TextEditingController(text: widget.alarm.label);
    _selectedRepeat = widget.alarm.repeatOption;
    _selectedGame = widget.alarm.gameType;
    _vibrate = widget.alarm.vibrate;
    _enableLight = widget.alarm.enableLight;
    _customDays = List<int>.from(widget.alarm.customDays);
  }

  @override
  void dispose() {
    _labelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Alarm'),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _saveAlarm,
            child: _isSaving 
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Save'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Time Picker
            _buildTimePickerSection(),
            
            const SizedBox(height: 24),
            
            // Label Input
            _buildLabelSection(),
            
            const SizedBox(height: 24),
            
            // Repeat Options
            _buildRepeatSection(),
            
            // Custom Days (if custom repeat is selected)
            if (_selectedRepeat == RepeatOption.custom) ...[
              const SizedBox(height: 16),
              _buildCustomDaysSection(),
            ],
            
            const SizedBox(height: 24),
            
            // Game Selection
            _buildGameSection(),
            
            const SizedBox(height: 24),
            
            // Additional Options
            _buildOptionsSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildTimePickerSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Alarm Time',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Center(
              child: GestureDetector(
                onTap: _showTimePicker,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                    ),
                  ),
                  child: Text(
                    TimeOfDay.fromDateTime(_selectedTime).format(context),
                    style: Theme.of(context).textTheme.displayMedium?.copyWith(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w300,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabelSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Alarm Label',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _labelController,
              decoration: const InputDecoration(
                hintText: 'e.g., Wake up for work',
                border: OutlineInputBorder(),
              ),
              maxLength: 50,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRepeatSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Repeat',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...RepeatOption.values.map((option) {
              return RadioListTile<RepeatOption>(
                title: Text(_getRepeatOptionText(option)),
                value: option,
                groupValue: _selectedRepeat,
                onChanged: (value) {
                  setState(() {
                    _selectedRepeat = value!;
                    if (value != RepeatOption.custom) {
                      _customDays.clear();
                    }
                  });
                },
                contentPadding: EdgeInsets.zero,
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomDaysSection() {
    const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Days',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: List.generate(7, (index) {
                final dayNum = index + 1;
                final isSelected = _customDays.contains(dayNum);
                
                return FilterChip(
                  label: Text(weekDays[index]),
                  selected: isSelected,
                  onSelected: (selected) {
                    setState(() {
                      if (selected) {
                        _customDays.add(dayNum);
                      } else {
                        _customDays.remove(dayNum);
                      }
                    });
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameSection() {
    return Consumer2<GameProvider, SubscriptionProvider>(
      builder: (context, gameProvider, subscriptionProvider, child) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Dismissal Game',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Choose which mini-game you must complete to dismiss the alarm',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
                const SizedBox(height: 16),
                ...GameType.values.map((gameType) {
                  final gameInfo = gameProvider.getGameInfo(gameType);
                  final isLocked = gameInfo['isPremium'] && !subscriptionProvider.isPremium;
                  
                  return RadioListTile<GameType>(
                    title: Row(
                      children: [
                        Icon(
                          gameInfo['icon'],
                          size: 20,
                          color: isLocked ? Colors.grey : gameInfo['color'],
                        ),
                        const SizedBox(width: 8),
                        Text(
                          gameInfo['name'],
                          style: TextStyle(
                            color: isLocked ? Colors.grey : null,
                          ),
                        ),
                        if (isLocked) ...[
                          const SizedBox(width: 8),
                          Icon(
                            Icons.lock,
                            size: 16,
                            color: AppColors.premiumGold,
                          ),
                        ],
                      ],
                    ),
                    subtitle: Text(
                      gameInfo['description'],
                      style: TextStyle(
                        color: isLocked ? Colors.grey : null,
                        fontSize: 12,
                      ),
                    ),
                    value: gameType,
                    groupValue: _selectedGame,
                    onChanged: isLocked ? null : (value) {
                      setState(() {
                        _selectedGame = value!;
                      });
                    },
                    contentPadding: EdgeInsets.zero,
                  );
                }),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildOptionsSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Options',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('Vibration'),
              subtitle: const Text('Vibrate when alarm rings'),
              value: _vibrate,
              onChanged: (value) {
                setState(() {
                  _vibrate = value;
                });
              },
              contentPadding: EdgeInsets.zero,
            ),
            SwitchListTile(
              title: const Text('Screen Light'),
              subtitle: const Text('Turn on screen when alarm rings'),
              value: _enableLight,
              onChanged: (value) {
                setState(() {
                  _enableLight = value;
                });
              },
              contentPadding: EdgeInsets.zero,
            ),
          ],
        ),
      ),
    );
  }

  String _getRepeatOptionText(RepeatOption option) {
    switch (option) {
      case RepeatOption.never:
        return 'Never (One time only)';
      case RepeatOption.daily:
        return 'Daily';
      case RepeatOption.weekdays:
        return 'Weekdays (Mon - Fri)';
      case RepeatOption.weekends:
        return 'Weekends (Sat - Sun)';
      case RepeatOption.custom:
        return 'Custom';
    }
  }

  Future<void> _showTimePicker() async {
    final TimeOfDay? time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_selectedTime),
    );
    
    if (time != null) {
      setState(() {
        _selectedTime = DateTime(
          _selectedTime.year,
          _selectedTime.month,
          _selectedTime.day,
          time.hour,
          time.minute,
        );
      });
    }
  }

  Future<void> _saveAlarm() async {
    if (_selectedRepeat == RepeatOption.custom && _customDays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one day')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final alarmProvider = context.read<AlarmProvider>();
      
      final updatedAlarm = widget.alarm.copyWith(
        label: _labelController.text.trim(),
        dateTime: _selectedTime,
        repeatOption: _selectedRepeat,
        customDays: _customDays,
        gameType: _selectedGame,
        vibrate: _vibrate,
        enableLight: _enableLight,
      );

      await alarmProvider.updateAlarm(updatedAlarm);
      
      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Alarm updated successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error updating alarm: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }
}
