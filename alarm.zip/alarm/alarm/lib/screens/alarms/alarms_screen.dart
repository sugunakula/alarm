import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/alarm_provider.dart';
import '../../providers/subscription_provider.dart';
import '../../models/alarm_model.dart';
import '../../utils/theme.dart';
import 'add_alarm_screen.dart';
import 'edit_alarm_screen.dart';

class AlarmsScreen extends StatefulWidget {
  const AlarmsScreen({super.key});

  @override
  State<AlarmsScreen> createState() => _AlarmsScreenState();
}

class _AlarmsScreenState extends State<AlarmsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alarms'),
        actions: [
          Consumer<AlarmProvider>(
            builder: (context, alarmProvider, child) {
              if (alarmProvider.alarms.isNotEmpty) {
                return PopupMenuButton<String>(
                  onSelected: (value) {
                    switch (value) {
                      case 'enable_all':
                        _enableAllAlarms();
                        break;
                      case 'disable_all':
                        _disableAllAlarms();
                        break;
                      case 'delete_all':
                        _showDeleteAllDialog();
                        break;
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'enable_all',
                      child: ListTile(
                        leading: Icon(Icons.alarm_on),
                        title: Text('Enable All'),
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'disable_all',
                      child: ListTile(
                        leading: Icon(Icons.alarm_off),
                        title: Text('Disable All'),
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete_all',
                      child: ListTile(
                        leading: Icon(Icons.delete_sweep),
                        title: Text('Delete All'),
                      ),
                    ),
                  ],
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: Consumer2<AlarmProvider, SubscriptionProvider>(
        builder: (context, alarmProvider, subscriptionProvider, child) {
          if (alarmProvider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (alarmProvider.error != null) {
            return _buildErrorWidget(alarmProvider.error!);
          }

          final alarms = alarmProvider.alarms;

          if (alarms.isEmpty) {
            return _buildEmptyState();
          }

          return RefreshIndicator(
            onRefresh: () => alarmProvider.refreshAlarms(),
            child: Column(
              children: [
                // Subscription limit warning for free users
                if (!subscriptionProvider.isPremium && alarms.length >= 5)
                  _buildLimitWarningCard(),
                
                // Alarms list
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: alarms.length,
                    itemBuilder: (context, index) {
                      final alarm = alarms[index];
                      return _buildAlarmCard(alarm);
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: Consumer<SubscriptionProvider>(
        builder: (context, subscriptionProvider, child) {
          return FloatingActionButton(
            onPressed: () => _addNewAlarm(subscriptionProvider),
            child: const Icon(Icons.add),
          );
        },
      ),
    );
  }

  Widget _buildErrorWidget(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            Text(
              'Something went wrong',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              error,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                context.read<AlarmProvider>().clearError();
                context.read<AlarmProvider>().refreshAlarms();
              },
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.alarm_add,
              size: 80,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
            ),
            const SizedBox(height: 24),
            Text(
              'No Alarms Yet',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Create your first alarm to start waking up with purpose. Each alarm comes with a fun mini-game to prevent snoozing!',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const AddAlarmScreen(),
                  ),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Create Alarm'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLimitWarningCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      child: Card(
        color: AppColors.warningYellow.withOpacity(0.1),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(
                Icons.warning_amber,
                color: AppColors.warningYellow,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Alarm Limit Reached',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Free users can create up to 5 alarms. Upgrade to premium for unlimited alarms.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () {
                  // Navigate to subscription screen
                },
                child: const Text('Upgrade'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAlarmCard(AlarmModel alarm) {
    final timeFormat = DateFormat('h:mm a');
    final nextTime = alarm.getNextAlarmTime();
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _editAlarm(alarm),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          timeFormat.format(alarm.dateTime),
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: alarm.isEnabled 
                                ? Theme.of(context).colorScheme.onSurface
                                : Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                          ),
                        ),
                        if (alarm.label.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            alarm.label,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: alarm.isEnabled 
                                  ? Theme.of(context).colorScheme.onSurface
                                  : Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  Switch(
                    value: alarm.isEnabled,
                    onChanged: (value) {
                      context.read<AlarmProvider>().toggleAlarm(alarm.id);
                    },
                  ),
                ],
              ),
              
              const SizedBox(height: 12),
              
              // Alarm details row
              Row(
                children: [
                  // Repeat info
                  _buildInfoChip(
                    _getRepeatText(alarm.repeatOption),
                    Icons.repeat,
                  ),
                  const SizedBox(width: 8),
                  
                  // Game type
                  _buildGameChip(alarm.gameType),
                  
                  const Spacer(),
                  
                  // Next alarm time
                  if (alarm.isEnabled && nextTime != null)
                    _buildNextTimeChip(nextTime),
                ],
              ),
              
              // Action buttons row
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton.icon(
                    onPressed: () => _editAlarm(alarm),
                    icon: const Icon(Icons.edit, size: 16),
                    label: const Text('Edit'),
                  ),
                  TextButton.icon(
                    onPressed: () => _deleteAlarm(alarm),
                    icon: const Icon(Icons.delete, size: 16),
                    label: const Text('Delete'),
                    style: TextButton.styleFrom(
                      foregroundColor: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoChip(String text, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.3),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12),
          const SizedBox(width: 4),
          Text(
            text,
            style: Theme.of(context).textTheme.labelSmall,
          ),
        ],
      ),
    );
  }

  Widget _buildGameChip(GameType gameType) {
    String gameName;
    Color gameColor;
    
    switch (gameType) {
      case GameType.mathEquation:
        gameName = 'Math';
        gameColor = AppColors.mathGame;
        break;
      case GameType.findTheBall:
        gameName = 'Ball';
        gameColor = AppColors.ballGame;
        break;
      case GameType.puzzleSolve:
        gameName = 'Puzzle';
        gameColor = AppColors.puzzleGame;
        break;
      case GameType.colorMatchBlitz:
        gameName = 'Color';
        gameColor = AppColors.colorGame;
        break;
      case GameType.memoryFlip:
        gameName = 'Memory';
        gameColor = AppColors.memoryGame;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: gameColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gameColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.games, size: 12, color: gameColor),
          const SizedBox(width: 4),
          Text(
            gameName,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: gameColor,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNextTimeChip(DateTime nextTime) {
    final now = DateTime.now();
    final difference = nextTime.difference(now);
    
    String timeText;
    if (difference.inDays > 0) {
      timeText = '${difference.inDays}d';
    } else if (difference.inHours > 0) {
      timeText = '${difference.inHours}h';
    } else {
      timeText = '${difference.inMinutes}m';
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        'in $timeText',
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  String _getRepeatText(RepeatOption repeatOption) {
    switch (repeatOption) {
      case RepeatOption.never:
        return 'Once';
      case RepeatOption.daily:
        return 'Daily';
      case RepeatOption.weekdays:
        return 'Weekdays';
      case RepeatOption.weekends:
        return 'Weekends';
      case RepeatOption.custom:
        return 'Custom';
    }
  }

  void _addNewAlarm(SubscriptionProvider subscriptionProvider) {
    final alarmProvider = context.read<AlarmProvider>();
    
    // Check alarm limit for free users
    if (!subscriptionProvider.isPremium && alarmProvider.alarms.length >= 5) {
      _showAlarmLimitDialog();
      return;
    }
    
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const AddAlarmScreen(),
      ),
    );
  }

  void _editAlarm(AlarmModel alarm) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => EditAlarmScreen(alarm: alarm),
      ),
    );
  }

  void _deleteAlarm(AlarmModel alarm) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Alarm'),
        content: Text(
          'Are you sure you want to delete the alarm at ${DateFormat('h:mm a').format(alarm.dateTime)}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<AlarmProvider>().deleteAlarm(alarm.id);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showAlarmLimitDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Alarm Limit Reached'),
        content: const Text(
          'Free users can create up to 5 alarms. Upgrade to premium for unlimited alarms and access to all mini-games.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Navigate to subscription screen
            },
            child: const Text('Upgrade'),
          ),
        ],
      ),
    );
  }

  void _showDeleteAllDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete All Alarms'),
        content: const Text(
          'Are you sure you want to delete all alarms? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              _deleteAllAlarms();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete All'),
          ),
        ],
      ),
    );
  }

  void _enableAllAlarms() {
    final alarmProvider = context.read<AlarmProvider>();
    for (final alarm in alarmProvider.alarms.where((a) => !a.isEnabled)) {
      alarmProvider.toggleAlarm(alarm.id);
    }
  }

  void _disableAllAlarms() {
    final alarmProvider = context.read<AlarmProvider>();
    for (final alarm in alarmProvider.activeAlarms) {
      alarmProvider.toggleAlarm(alarm.id);
    }
  }

  void _deleteAllAlarms() {
    final alarmProvider = context.read<AlarmProvider>();
    final alarmsToDelete = List<AlarmModel>.from(alarmProvider.alarms);
    
    for (final alarm in alarmsToDelete) {
      alarmProvider.deleteAlarm(alarm.id);
    }
  }
}
