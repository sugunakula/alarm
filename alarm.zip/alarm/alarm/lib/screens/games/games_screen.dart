import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/game_provider.dart';
import '../../providers/subscription_provider.dart';
import '../../models/alarm_model.dart';
import '../../models/game_model.dart';
import '../../utils/theme.dart';
import '../subscription/subscription_screen.dart';
import 'game_detail_screen.dart';

class GamesScreen extends StatefulWidget {
  const GamesScreen({super.key});

  @override
  State<GamesScreen> createState() => _GamesScreenState();
}

class _GamesScreenState extends State<GamesScreen> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mini-Games'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'All Games'),
            Tab(text: 'Statistics'),
          ],
        ),
        actions: [
          Consumer<SubscriptionProvider>(
            builder: (context, subscriptionProvider, child) {
              if (!subscriptionProvider.isPremium) {
                return IconButton(
                  icon: const Icon(Icons.upgrade),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const SubscriptionScreen(),
                      ),
                    );
                  },
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildGamesTab(),
          _buildStatisticsTab(),
        ],
      ),
    );
  }

  Widget _buildGamesTab() {
    return Consumer2<GameProvider, SubscriptionProvider>(
      builder: (context, gameProvider, subscriptionProvider, child) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Premium Status Card
              if (!subscriptionProvider.isPremium) _buildPremiumStatusCard(),
              
              // Games Grid
              _buildGamesGrid(gameProvider, subscriptionProvider),
              
              const SizedBox(height: 24),
              
              // How Games Work Section
              _buildHowGamesWorkSection(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPremiumStatusCard() {
    return Card(
      color: AppColors.premiumGold.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              Icons.lock,
              color: AppColors.premiumGold,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Unlock All Games',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Get premium to access all 5 mini-games',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const SubscriptionScreen(),
                  ),
                );
              },
              child: const Text('Upgrade'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGamesGrid(GameProvider gameProvider, SubscriptionProvider subscriptionProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Available Games',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 1.2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          itemCount: GameType.values.length,
          itemBuilder: (context, index) {
            final gameType = GameType.values[index];
            final gameInfo = gameProvider.getGameInfo(gameType);
            final isLocked = gameInfo['isPremium'] && !subscriptionProvider.isPremium;
            final stats = gameProvider.gameStats[gameType];
            
            return _buildGameCard(
              gameType: gameType,
              gameInfo: gameInfo,
              stats: stats,
              isLocked: isLocked,
            );
          },
        ),
      ],
    );
  }

  Widget _buildGameCard({
    required GameType gameType,
    required Map<String, dynamic> gameInfo,
    GameStats? stats,
    required bool isLocked,
  }) {
    return Card(
      child: InkWell(
        onTap: isLocked ? _showPremiumDialog : () => _navigateToGameDetail(gameType),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: (gameInfo['color'] as Color).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Icon(
                      gameInfo['icon'],
                      size: 24,
                      color: isLocked ? Colors.grey : gameInfo['color'],
                    ),
                  ),
                  if (isLocked)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: AppColors.premiumGold,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.lock,
                          size: 10,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                gameInfo['name'],
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: isLocked ? Colors.grey : null,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              if (stats != null && !isLocked) ...[
                Text(
                  '${(stats.successRate * 100).toInt()}% success',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ] else if (isLocked) ...[
                Text(
                  'Premium',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppColors.premiumGold,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ] else ...[
                Text(
                  'Not played yet',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatisticsTab() {
    return Consumer<GameProvider>(
      builder: (context, gameProvider, child) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildOverallStats(gameProvider),
              const SizedBox(height: 24),
              _buildGameStatsList(gameProvider),
            ],
          ),
        );
      },
    );
  }

  Widget _buildOverallStats(GameProvider gameProvider) {
    final allStats = gameProvider.gameStats.values;
    final totalPlayed = allStats.fold(0, (sum, stats) => sum + stats.totalPlayed);
    final totalCompleted = allStats.fold(0, (sum, stats) => sum + stats.totalCompleted);
    final overallSuccessRate = totalPlayed > 0 ? totalCompleted / totalPlayed : 0.0;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Overall Statistics',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    'Games Played',
                    totalPlayed.toString(),
                    Icons.games,
                  ),
                ),
                Expanded(
                  child: _buildStatItem(
                    'Success Rate',
                    '${(overallSuccessRate * 100).toInt()}%',
                    Icons.check_circle,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(
          icon,
          size: 32,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildGameStatsList(GameProvider gameProvider) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Game Statistics',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 16),
        ...GameType.values.map((gameType) {
          final gameInfo = gameProvider.getGameInfo(gameType);
          final stats = gameProvider.gameStats[gameType];
          
          return _buildGameStatCard(gameType, gameInfo, stats);
        }),
      ],
    );
  }

  Widget _buildGameStatCard(
    GameType gameType,
    Map<String, dynamic> gameInfo,
    GameStats? stats,
  ) {
    return Card(
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: (gameInfo['color'] as Color).withOpacity(0.2),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(
            gameInfo['icon'],
            color: gameInfo['color'],
          ),
        ),
        title: Text(gameInfo['name']),
        subtitle: stats != null
            ? Text(
                'Played: ${stats.totalPlayed} | Success: ${(stats.successRate * 100).toInt()}%',
              )
            : const Text('Not played yet'),
        trailing: stats != null && stats.totalPlayed > 0
            ? Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Best: ${stats.bestScore}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              )
            : null,
        onTap: () => _navigateToGameDetail(gameType),
      ),
    );
  }

  Widget _buildHowGamesWorkSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'How Games Work',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'When your alarm rings, you must complete a randomly selected mini-game to dismiss it. This prevents snoozing and helps you wake up more alertly.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 8),
            Text(
              '• Games adapt to your skill level\n'
              '• Failed attempts require game restart\n'
              '• Premium users get access to all 5 games\n'
              '• Free users can play the Math Equation game',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _navigateToGameDetail(GameType gameType) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => GameDetailScreen(gameType: gameType),
      ),
    );
  }

  void _showPremiumDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Premium Feature'),
        content: const Text(
          'This game is available for premium subscribers only. Upgrade to unlock all 5 mini-games!',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const SubscriptionScreen(),
                ),
              );
            },
            child: const Text('Upgrade'),
          ),
        ],
      ),
    );
  }
}
