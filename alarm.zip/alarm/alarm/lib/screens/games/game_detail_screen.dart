import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/game_provider.dart';
import '../../models/alarm_model.dart';
import '../../models/game_model.dart';
import '../../games/math_equation_game.dart';
import '../../games/find_the_ball_game.dart';
import '../../games/color_match_blitz_game.dart';
import '../../games/memory_flip_game.dart';
import '../../games/puzzle_solve_game.dart';

class GameDetailScreen extends StatelessWidget {
  final GameType gameType;
  
  const GameDetailScreen({super.key, required this.gameType});

  @override
  Widget build(BuildContext context) {
    return Consumer<GameProvider>(
      builder: (context, gameProvider, child) {
        final gameInfo = gameProvider.getGameInfo(gameType);
        final stats = gameProvider.gameStats[gameType];
        
        return Scaffold(
          appBar: AppBar(
            title: Text(gameInfo['name']),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Game Icon and Description
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: (gameInfo['color'] as Color).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(40),
                          ),
                          child: Icon(
                            gameInfo['icon'],
                            size: 40,
                            color: gameInfo['color'],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          gameInfo['name'],
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          gameInfo['description'],
                          style: Theme.of(context).textTheme.bodyMedium,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Statistics
                if (stats != null) ...[
                  Text(
                    'Your Statistics',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: _buildStatItem(
                                  context,
                                  'Games Played',
                                  stats.totalPlayed.toString(),
                                  Icons.games,
                                ),
                              ),
                              Expanded(
                                child: _buildStatItem(
                                  context,
                                  'Success Rate',
                                  '${(stats.successRate * 100).toInt()}%',
                                  Icons.check_circle,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Row(
                            children: [
                              Expanded(
                                child: _buildStatItem(
                                  context,
                                  'Best Score',
                                  stats.bestScore.toString(),
                                  Icons.star,
                                ),
                              ),
                              Expanded(
                                child: _buildStatItem(
                                  context,
                                  'Avg Time',
                                  '${stats.averageTime.inSeconds}s',
                                  Icons.timer,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                ],
                
                // How to Play
                Text(
                  'How to Play',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(
                      _getGameInstructions(gameType),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                
                // Practice Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      _startPracticeMode(context, gameType);
                    },
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Practice Mode'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatItem(BuildContext context, String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(
          icon,
          size: 32,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  void _startPracticeMode(BuildContext context, GameType gameType) {
    Widget gameWidget;
    
    switch (gameType) {
      case GameType.mathEquation:
        gameWidget = MathEquationGame(
          isPracticeMode: true,
          config: GameConfig(),
        );
        break;
      case GameType.findTheBall:
        gameWidget = FindTheBallGame(
          isPracticeMode: true,
          config: GameConfig(),
        );
        break;
      case GameType.colorMatchBlitz:
        gameWidget = ColorMatchBlitzGame(
          isPracticeMode: true,
          config: GameConfig(),
        );
        break;
      case GameType.memoryFlip:
        gameWidget = MemoryFlipGame(
          isPracticeMode: true,
          config: GameConfig(),
        );
        break;
      case GameType.puzzleSolve:
        gameWidget = PuzzleSolveGame(
          isPracticeMode: true,
          config: GameConfig(),
        );
        break;
    }
    
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => Scaffold(
          appBar: AppBar(
            title: Text('Practice: ${Provider.of<GameProvider>(context, listen: false).getGameInfo(gameType)['name']}'),
            backgroundColor: Colors.transparent,
            elevation: 0,
          ),
          body: gameWidget,
        ),
      ),
    );
  }

  String _getGameInstructions(GameType gameType) {
    switch (gameType) {
      case GameType.mathEquation:
        return 'Solve arithmetic problems quickly and accurately. The difficulty adapts based on your performance. Get the answer right to dismiss your alarm!';
        
      case GameType.findTheBall:
        return 'Watch carefully as the cups shuffle and keep track of which cup hides the ball. Click the correct cup to win. The shuffling gets faster as you improve!';
        
      case GameType.puzzleSolve:
        return 'Slide the puzzle pieces to complete the image. Use the empty space to move tiles around. Think strategically to solve it in the minimum number of moves!';
        
      case GameType.colorMatchBlitz:
        return 'Match the colors as quickly as possible! Tap the color that matches the target. Speed and accuracy are key to achieving high scores!';
        
      case GameType.memoryFlip:
        return 'Flip cards to find matching pairs. Remember where each card is located and match all pairs to win. The number of cards increases with difficulty!';
    }
  }
}
