import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/subscription_provider.dart';
import '../../utils/theme.dart';

class SubscriptionScreen extends StatelessWidget {
  const SubscriptionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Premium'),
      ),
      body: Consumer<SubscriptionProvider>(
        builder: (context, subscriptionProvider, child) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: AppColors.premiumGold,
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: const Icon(
                      Icons.star,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    subscriptionProvider.isPremium 
                        ? 'Premium Active' 
                        : 'Premium Features',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    subscriptionProvider.isPremium
                        ? 'You have access to all premium features'
                        : 'Subscription system coming soon!\n\nPremium features will include:\n• All 5 mini-games\n• Unlimited alarms\n• Custom themes\n• Priority support',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 32),
                  if (!subscriptionProvider.isPremium) 
                    ElevatedButton(
                      onPressed: () {
                        // Temporarily enable premium for development
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Premium features temporarily enabled for development'),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.premiumGold,
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Enable Premium (Dev Mode)'),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppColors.premiumGold.withOpacity(0.1),
            Colors.transparent,
          ],
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: AppColors.premiumGold,
                borderRadius: BorderRadius.circular(40),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.premiumGold.withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: const Icon(
                Icons.star,
                size: 40,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              subscriptionProvider.isPremium 
                  ? 'Premium Active' 
                  : 'Upgrade to Premium',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              subscriptionProvider.isPremium
                  ? 'You have access to all premium features'
                  : 'Unlock all games and advanced features',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            if (subscriptionProvider.isPremium) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.premiumGold.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  subscriptionProvider.subscriptionStatusText,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: AppColors.premiumGold,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentStatusSection(SubscriptionProvider subscriptionProvider) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Subscription Details',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              _buildStatusRow('Status', subscriptionProvider.subscriptionStatusText),
              if (subscriptionProvider.subscription.isTrialActive)
                _buildStatusRow('Trial ends', 'in ${subscriptionProvider.subscription.daysRemaining} days')
              else if (subscriptionProvider.subscription.expirationDate != null)
                _buildStatusRow('Renews', 'in ${subscriptionProvider.subscription.daysRemaining} days'),
              _buildStatusRow('Auto-renew', subscriptionProvider.subscription.autoRenew ? 'On' : 'Off'),
              
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _showCancelDialog(),
                      child: const Text('Cancel Subscription'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: subscriptionProvider.restorePurchases,
                      child: const Text('Restore Purchases'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturesSection() {
    const features = [
      {
        'icon': Icons.games,
        'title': 'All 5 Mini-Games',
        'description': 'Access to Math, Ball, Puzzle, Color Match, and Memory games',
      },
      {
        'icon': Icons.tune,
        'title': 'Advanced Customization',
        'description': 'Custom alarm sounds, themes, and personalization options',
      },
      {
        'icon': Icons.alarm,
        'title': 'Unlimited Alarms',
        'description': 'Create as many alarms as you need without restrictions',
      },
      {
        'icon': Icons.support_agent,
        'title': 'Priority Support',
        'description': 'Get help faster with dedicated premium customer support',
      },
      {
        'icon': Icons.ad_units_off,
        'title': 'Ad-Free Experience',
        'description': 'Enjoy NoSnooz without any interruptions or advertisements',
      },
      {
        'icon': Icons.cloud_sync,
        'title': 'Cloud Sync',
        'description': 'Sync your alarms and settings across all your devices',
      },
    ];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Premium Features',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ...features.map((feature) => _buildFeatureItem(
            feature['icon'] as IconData,
            feature['title'] as String,
            feature['description'] as String,
          )),
        ],
      ),
    );
  }

  Widget _buildFeatureItem(IconData icon, String title, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AppColors.premiumGold.withOpacity(0.2),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Icon(
              icon,
              color: AppColors.premiumGold,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPricingSection(SubscriptionProvider subscriptionProvider) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose Your Plan',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          ...SubscriptionPlan.availablePlans.asMap().entries.map((entry) {
            final index = entry.key;
            final plan = entry.value;
            final isSelected = _selectedPlanIndex == index;
            
            return _buildPlanCard(plan, isSelected, () {
              setState(() {
                _selectedPlanIndex = index;
              });
            });
          }),
        ],
      ),
    );
  }

  Widget _buildPlanCard(SubscriptionPlan plan, bool isSelected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          border: Border.all(
            color: isSelected 
                ? AppColors.premiumGold 
                : Theme.of(context).colorScheme.outline.withOpacity(0.3),
            width: isSelected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
          color: isSelected 
              ? AppColors.premiumGold.withOpacity(0.1) 
              : Theme.of(context).cardColor,
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Radio<bool>(
                value: true,
                groupValue: isSelected,
                onChanged: (_) => onTap(),
                activeColor: AppColors.premiumGold,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          plan.name,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (plan.period == SubscriptionPeriod.yearly) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.successGreen,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              'SAVE 50%',
                              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      plan.formattedPrice,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: AppColors.premiumGold,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (plan.period == SubscriptionPeriod.yearly) ...[
                      const SizedBox(height: 2),
                      Text(
                        'Just \$2.50/month',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionButtons(SubscriptionProvider subscriptionProvider) {
    final selectedPlan = SubscriptionPlan.availablePlans[_selectedPlanIndex];
    
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: subscriptionProvider.purchaseInProgress 
                  ? null 
                  : () => _startTrial(selectedPlan, subscriptionProvider),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.premiumGold,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: subscriptionProvider.purchaseInProgress
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Text(
                      selectedPlan.hasTrial 
                          ? 'Start ${selectedPlan.trialDays}-Day Free Trial'
                          : 'Subscribe Now',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: subscriptionProvider.purchaseInProgress 
                  ? null 
                  : () => _purchaseSubscription(selectedPlan, subscriptionProvider),
              child: Text('Purchase ${selectedPlan.formattedPrice}'),
            ),
          ),
          const SizedBox(height: 16),
          TextButton(
            onPressed: subscriptionProvider.restorePurchases,
            child: const Text('Restore Purchases'),
          ),
        ],
      ),
    );
  }

  Widget _buildFooterSection() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Text(
            'Subscription Terms',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '• Free trial automatically converts to paid subscription\n'
            '• Cancel anytime in your device settings\n'
            '• Subscription renews automatically unless cancelled\n'
            '• Unused trial time is forfeited upon subscription purchase',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              TextButton(
                onPressed: () {
                  // TODO: Show privacy policy
                },
                child: const Text('Privacy Policy'),
              ),
              TextButton(
                onPressed: () {
                  // TODO: Show terms of service
                },
                child: const Text('Terms of Service'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _startTrial(SubscriptionPlan plan, SubscriptionProvider subscriptionProvider) {
    if (!plan.hasTrial) {
      _purchaseSubscription(plan, subscriptionProvider);
      return;
    }

    subscriptionProvider.startTrial(plan.id).then((_) {
      if (subscriptionProvider.error == null) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${plan.trialDays}-day free trial started!'),
            backgroundColor: AppColors.successGreen,
          ),
        );
      } else {
        _showErrorDialog(subscriptionProvider.error!);
      }
    });
  }

  void _purchaseSubscription(SubscriptionPlan plan, SubscriptionProvider subscriptionProvider) {
    subscriptionProvider.purchaseSubscription(plan.id).then((_) {
      if (subscriptionProvider.error == null) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Subscription activated successfully!'),
            backgroundColor: AppColors.successGreen,
          ),
        );
      } else {
        _showErrorDialog(subscriptionProvider.error!);
      }
    });
  }

  void _showCancelDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Cancel Subscription'),
        content: const Text(
          'To cancel your subscription, please go to your device settings:\n\n'
          'iOS: Settings > Apple ID > Subscriptions\n'
          'Android: Play Store > Account > Subscriptions',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String error) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(error),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}
