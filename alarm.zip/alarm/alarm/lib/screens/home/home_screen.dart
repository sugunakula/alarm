import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/alarm_provider.dart';
import '../../models/alarm_model.dart';
import '../../utils/theme.dart';
import '../alarms/add_alarm_screen.dart';
import '../settings/app_info_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Stream<DateTime> _timeStream;

  @override
  void initState() {
    super.initState();
    _timeStream = Stream.periodic(const Duration(seconds: 1), (_) => DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NoSnooz'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'about':
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const AppInfoScreen(),
                    ),
                  );
                  break;
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'about',
                child: ListTile(
                  leading: Icon(Icons.info_outline),
                  title: Text('About NoSnooz'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => context.read<AlarmProvider>().refreshAlarms(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Current Time Display
              _buildCurrentTimeCard(),
              
              const SizedBox(height: 24),
              
              // Next Alarm Card
              _buildNextAlarmCard(),
              
              const SizedBox(height: 24),
              
              // Quick Actions
              _buildQuickActions(),
              
              const SizedBox(height: 24),
              
              // Active Alarms Overview
              _buildActiveAlarmsOverview(),
              
              const SizedBox(height: 24),
              
              // Premium Features Highlight
              _buildPremiumHighlight(),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const AddAlarmScreen(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildCurrentTimeCard() {
    return StreamBuilder<DateTime>(
      stream: _timeStream,
      builder: (context, snapshot) {
        final now = snapshot.data ?? DateTime.now();
        final timeFormat = DateFormat('h:mm a');
        final dateFormat = DateFormat('EEEE, MMMM d');
        
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Text(
                  timeFormat.format(now),
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                    fontWeight: FontWeight.w300,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  dateFormat.format(now),
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildNextAlarmCard() {
    return Consumer<AlarmProvider>(
      builder: (context, alarmProvider, child) {
        final nextAlarm = alarmProvider.nextAlarm;
        
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.alarm,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Next Alarm',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (nextAlarm != null) ...[
                  _buildAlarmInfo(nextAlarm),
                ] else ...[
                  Text(
                    'No active alarms',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap the + button to create your first alarm',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildAlarmInfo(AlarmModel alarm) {
    final nextTime = alarm.getNextAlarmTime();
    if (nextTime == null) return const SizedBox.shrink();
    
    final timeFormat = DateFormat('h:mm a');
    final dateFormat = DateFormat('EEE, MMM d');
    final now = DateTime.now();
    final difference = nextTime.difference(now);
    
    String timeUntil;
    if (difference.inDays > 0) {
      timeUntil = 'in ${difference.inDays} day${difference.inDays > 1 ? 's' : ''}';
    } else if (difference.inHours > 0) {
      timeUntil = 'in ${difference.inHours} hour${difference.inHours > 1 ? 's' : ''}';
    } else if (difference.inMinutes > 0) {
      timeUntil = 'in ${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''}';
    } else {
      timeUntil = 'very soon';
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              timeFormat.format(nextTime),
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                timeUntil,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          dateFormat.format(nextTime),
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
          ),
        ),
        if (alarm.label.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(
            alarm.label,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ],
        const SizedBox(height: 8),
        _buildGameBadge(alarm.gameType),
      ],
    );
  }

  Widget _buildGameBadge(GameType gameType) {
    String gameName;
    Color gameColor;
    
    switch (gameType) {
      case GameType.mathEquation:
        gameName = 'Math';
        gameColor = AppColors.mathGame;
        break;
      case GameType.findTheBall:
        gameName = 'Find Ball';
        gameColor = AppColors.ballGame;
        break;
      case GameType.puzzleSolve:
        gameName = 'Puzzle';
        gameColor = AppColors.puzzleGame;
        break;
      case GameType.colorMatchBlitz:
        gameName = 'Color Match';
        gameColor = AppColors.colorGame;
        break;
      case GameType.memoryFlip:
        gameName = 'Memory';
        gameColor = AppColors.memoryGame;
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: gameColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gameColor.withOpacity(0.3)),
      ),
      child: Text(
        'Game: $gameName',
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: gameColor,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildQuickActionCard(
                icon: Icons.add_alarm,
                title: 'Add Alarm',
                subtitle: 'Create new',
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const AddAlarmScreen(),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Consumer<AlarmProvider>(
                builder: (context, alarmProvider, child) {
                  final hasActiveAlarms = alarmProvider.activeAlarms.isNotEmpty;
                  return _buildQuickActionCard(
                    icon: hasActiveAlarms ? Icons.alarm_off : Icons.alarm_on,
                    title: hasActiveAlarms ? 'Disable All' : 'Enable All',
                    subtitle: hasActiveAlarms ? 'Turn off' : 'Turn on',
                    onTap: hasActiveAlarms ? _disableAllAlarms : _enableAllAlarms,
                  );
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(
                icon,
                size: 32,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall,
                textAlign: TextAlign.center,
              ),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActiveAlarmsOverview() {
    return Consumer<AlarmProvider>(
      builder: (context, alarmProvider, child) {
        final activeAlarms = alarmProvider.activeAlarms;
        
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Active Alarms',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  '${activeAlarms.length}',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (activeAlarms.isEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Center(
                    child: Text(
                      'No active alarms',
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                      ),
                    ),
                  ),
                ),
              ),
            ] else ...[
              ...activeAlarms.take(3).map((alarm) => _buildAlarmPreviewCard(alarm)),
              if (activeAlarms.length > 3) ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Center(
                      child: Text(
                        '+${activeAlarms.length - 3} more alarms',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ],
        );
      },
    );
  }

  Widget _buildAlarmPreviewCard(AlarmModel alarm) {
    final timeFormat = DateFormat('h:mm a');
    
    return Card(
      child: ListTile(
        leading: Icon(
          Icons.alarm,
          color: Theme.of(context).colorScheme.primary,
        ),
        title: Text(timeFormat.format(alarm.dateTime)),
        subtitle: alarm.label.isNotEmpty ? Text(alarm.label) : null,
        trailing: Switch(
          value: alarm.isEnabled,
          onChanged: (value) {
            context.read<AlarmProvider>().toggleAlarm(alarm.id);
          },
        ),
      ),
    );
  }

  // Premium functionality removed - all features are now available

  void _disableAllAlarms() {
    final alarmProvider = context.read<AlarmProvider>();
    for (final alarm in alarmProvider.activeAlarms) {
      alarmProvider.toggleAlarm(alarm.id);
    }
  }

  void _enableAllAlarms() {
    final alarmProvider = context.read<AlarmProvider>();
    for (final alarm in alarmProvider.alarms.where((a) => !a.isEnabled)) {
      alarmProvider.toggleAlarm(alarm.id);
    }
  }
}
