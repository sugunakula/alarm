enum SubscriptionTier {
  free,
  premium,
}

enum SubscriptionPeriod {
  monthly,
  yearly,
}

class SubscriptionPlan {
  final String id;
  final String name;
  final SubscriptionPeriod period;
  final double price;
  final String currency;
  final List<String> features;
  final bool hasTrial;
  final int trialDays;

  const SubscriptionPlan({
    required this.id,
    required this.name,
    required this.period,
    required this.price,
    this.currency = 'USD',
    required this.features,
    this.hasTrial = false,
    this.trialDays = 0,
  });

  static const List<SubscriptionPlan> availablePlans = [
    SubscriptionPlan(
      id: 'nosnooz_monthly',
      name: 'Premium Monthly',
      period: SubscriptionPeriod.monthly,
      price: 4.99,
      features: [
        'All 5 mini-games unlocked',
        'Advanced customization options',
        'Priority customer support',
        'No ads',
        'Custom alarm sounds',
        'Unlimited alarms',
      ],
      hasTrial: true,
      trialDays: 7,
    ),
    SubscriptionPlan(
      id: 'nosnooz_yearly',
      name: 'Premium Yearly',
      period: SubscriptionPeriod.yearly,
      price: 29.99,
      features: [
        'All 5 mini-games unlocked',
        'Advanced customization options',
        'Priority customer support',
        'No ads',
        'Custom alarm sounds',
        'Unlimited alarms',
        '50% savings compared to monthly',
      ],
      hasTrial: true,
      trialDays: 7,
    ),
  ];

  String get formattedPrice {
    switch (period) {
      case SubscriptionPeriod.monthly:
        return '\$${price.toStringAsFixed(2)}/month';
      case SubscriptionPeriod.yearly:
        return '\$${price.toStringAsFixed(2)}/year';
    }
  }

  String get savingsText {
    if (period == SubscriptionPeriod.yearly) {
      final monthlyEquivalent = price / 12;
      final monthlySavings = 4.99 - monthlyEquivalent;
      final percentSavings = (monthlySavings / 4.99 * 100).round();
      return 'Save $percentSavings%';
    }
    return '';
  }
}

class UserSubscription {
  final SubscriptionTier tier;
  final String? planId;
  final DateTime? purchaseDate;
  final DateTime? expirationDate;
  final bool isTrialActive;
  final DateTime? trialEndDate;
  final bool autoRenew;

  const UserSubscription({
    required this.tier,
    this.planId,
    this.purchaseDate,
    this.expirationDate,
    this.isTrialActive = false,
    this.trialEndDate,
    this.autoRenew = false,
  });

  bool get isPremium => tier == SubscriptionTier.premium;
  
  bool get isActive {
    if (tier == SubscriptionTier.free) return true;
    
    final now = DateTime.now();
    
    if (isTrialActive && trialEndDate != null) {
      return now.isBefore(trialEndDate!);
    }
    
    if (expirationDate != null) {
      return now.isBefore(expirationDate!);
    }
    
    return false;
  }

  bool get isExpired => !isActive && tier == SubscriptionTier.premium;

  int get daysRemaining {
    if (!isActive) return 0;
    
    final now = DateTime.now();
    final endDate = isTrialActive ? trialEndDate : expirationDate;
    
    if (endDate != null) {
      return endDate.difference(now).inDays;
    }
    
    return 0;
  }

  Map<String, dynamic> toJson() {
    return {
      'tier': tier.index,
      'planId': planId,
      'purchaseDate': purchaseDate?.millisecondsSinceEpoch,
      'expirationDate': expirationDate?.millisecondsSinceEpoch,
      'isTrialActive': isTrialActive,
      'trialEndDate': trialEndDate?.millisecondsSinceEpoch,
      'autoRenew': autoRenew,
    };
  }

  factory UserSubscription.fromJson(Map<String, dynamic> json) {
    return UserSubscription(
      tier: SubscriptionTier.values[json['tier'] ?? 0],
      planId: json['planId'],
      purchaseDate: json['purchaseDate'] != null
          ? DateTime.fromMillisecondsSinceEpoch(json['purchaseDate'])
          : null,
      expirationDate: json['expirationDate'] != null
          ? DateTime.fromMillisecondsSinceEpoch(json['expirationDate'])
          : null,
      isTrialActive: json['isTrialActive'] ?? false,
      trialEndDate: json['trialEndDate'] != null
          ? DateTime.fromMillisecondsSinceEpoch(json['trialEndDate'])
          : null,
      autoRenew: json['autoRenew'] ?? false,
    );
  }

  UserSubscription copyWith({
    SubscriptionTier? tier,
    String? planId,
    DateTime? purchaseDate,
    DateTime? expirationDate,
    bool? isTrialActive,
    DateTime? trialEndDate,
    bool? autoRenew,
  }) {
    return UserSubscription(
      tier: tier ?? this.tier,
      planId: planId ?? this.planId,
      purchaseDate: purchaseDate ?? this.purchaseDate,
      expirationDate: expirationDate ?? this.expirationDate,
      isTrialActive: isTrialActive ?? this.isTrialActive,
      trialEndDate: trialEndDate ?? this.trialEndDate,
      autoRenew: autoRenew ?? this.autoRenew,
    );
  }

  static const UserSubscription defaultFree = UserSubscription(
    tier: SubscriptionTier.free,
  );
}
