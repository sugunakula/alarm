import 'package:flutter/material.dart';

enum SoundCategory {
  classic,
  nature,
  music,
  voice,
  custom,
}

class AlarmSound {
  final String id;
  final String name;
  final String description;
  final String assetPath;
  final SoundCategory category;
  final Duration duration;
  final bool isPremium;
  final IconData icon;

  const AlarmSound({
    required this.id,
    required this.name,
    required this.description,
    required this.assetPath,
    required this.category,
    required this.duration,
    this.isPremium = false,
    this.icon = Icons.music_note,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'assetPath': assetPath,
      'category': category.index,
      'duration': duration.inMilliseconds,
      'isPremium': isPremium,
    };
  }

  factory AlarmSound.fromJson(Map<String, dynamic> json) {
    return AlarmSound(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      assetPath: json['assetPath'],
      category: SoundCategory.values[json['category']],
      duration: Duration(milliseconds: json['duration']),
      isPremium: json['isPremium'] ?? false,
    );
  }
}

class SoundManager {
  static const List<AlarmSound> availableSounds = [
    // Classic Sounds (Free)
    AlarmSound(
      id: 'classic_beep',
      name: 'Classic Beep',
      description: 'Traditional alarm beeping sound',
      assetPath: 'notification_sound', // System default
      category: SoundCategory.classic,
      duration: Duration(seconds: 3),
      isPremium: false,
      icon: Icons.alarm,
    ),
    AlarmSound(
      id: 'digital_alarm',
      name: 'Digital Alarm',
      description: 'Electronic digital clock sound',
      assetPath: 'notification_sound', // System default
      category: SoundCategory.classic,
      duration: Duration(seconds: 5),
      isPremium: false,
      icon: Icons.access_alarm,
    ),
    AlarmSound(
      id: 'bell_ring',
      name: 'Bell Ring',
      description: 'Traditional bell ringing',
      assetPath: 'notification_sound', // System default
      category: SoundCategory.classic,
      duration: Duration(seconds: 4),
      isPremium: false,
      icon: Icons.notifications_active,
    ),

    // Nature Sounds (Premium)
    AlarmSound(
      id: 'birds_chirping',
      name: 'Birds Chirping',
      description: 'Gentle morning birds singing',
      assetPath: 'premium_sound_1', // Placeholder
      category: SoundCategory.nature,
      duration: Duration(seconds: 8),
      isPremium: true,
      icon: Icons.park,
    ),
    AlarmSound(
      id: 'ocean_waves',
      name: 'Ocean Waves',
      description: 'Peaceful ocean waves crashing',
      assetPath: 'premium_sound_2', // Placeholder
      category: SoundCategory.nature,
      duration: Duration(seconds: 10),
      isPremium: true,
      icon: Icons.waves,
    ),
    AlarmSound(
      id: 'rainfall',
      name: 'Gentle Rain',
      description: 'Soft rainfall sounds',
      assetPath: 'premium_sound_3', // Placeholder
      category: SoundCategory.nature,
      duration: Duration(seconds: 12),
      isPremium: true,
      icon: Icons.grain,
    ),
    AlarmSound(
      id: 'forest_ambience',
      name: 'Forest Morning',
      description: 'Peaceful forest atmosphere',
      assetPath: 'premium_sound_4', // Placeholder
      category: SoundCategory.nature,
      duration: Duration(seconds: 15),
      isPremium: true,
      icon: Icons.forest,
    ),

    // Music Sounds (Premium)
    AlarmSound(
      id: 'piano_melody',
      name: 'Piano Melody',
      description: 'Gentle piano wake-up tune',
      assetPath: 'premium_sound_5', // Placeholder
      category: SoundCategory.music,
      duration: Duration(seconds: 20),
      isPremium: true,
      icon: Icons.piano,
    ),
    AlarmSound(
      id: 'guitar_strum',
      name: 'Guitar Strum',
      description: 'Acoustic guitar morning chord',
      assetPath: 'premium_sound_6', // Placeholder
      category: SoundCategory.music,
      duration: Duration(seconds: 6),
      isPremium: true,
      icon: Icons.music_note,
    ),
    AlarmSound(
      id: 'chimes',
      name: 'Wind Chimes',
      description: 'Soothing wind chimes melody',
      assetPath: 'premium_sound_7', // Placeholder
      category: SoundCategory.music,
      duration: Duration(seconds: 8),
      isPremium: true,
      icon: Icons.music_off,
    ),

    // Voice Sounds (Premium)
    AlarmSound(
      id: 'gentle_voice',
      name: 'Gentle Voice',
      description: 'Soft "Good morning" wake up call',
      assetPath: 'premium_sound_8', // Placeholder
      category: SoundCategory.voice,
      duration: Duration(seconds: 3),
      isPremium: true,
      icon: Icons.record_voice_over,
    ),
    AlarmSound(
      id: 'motivational_voice',
      name: 'Motivational Voice',
      description: 'Energetic wake up motivation',
      assetPath: 'premium_sound_9', // Placeholder
      category: SoundCategory.voice,
      duration: Duration(seconds: 5),
      isPremium: true,
      icon: Icons.campaign,
    ),
  ];

  static List<AlarmSound> getSoundsByCategory(SoundCategory category, {bool includeFreeSounds = true}) {
    return availableSounds.where((sound) {
      if (sound.category != category) return false;
      if (!includeFreeSounds && !sound.isPremium) return false;
      return true;
    }).toList();
  }

  static List<AlarmSound> getFreeSounds() {
    return availableSounds.where((sound) => !sound.isPremium).toList();
  }

  static List<AlarmSound> getPremiumSounds() {
    return availableSounds.where((sound) => sound.isPremium).toList();
  }

  static AlarmSound? getSoundById(String id) {
    try {
      return availableSounds.firstWhere((sound) => sound.id == id);
    } catch (e) {
      return null;
    }
  }

  static AlarmSound get defaultSound => availableSounds.first;

  static String getCategoryName(SoundCategory category) {
    switch (category) {
      case SoundCategory.classic:
        return 'Classic Alarms';
      case SoundCategory.nature:
        return 'Nature Sounds';
      case SoundCategory.music:
        return 'Musical Tones';
      case SoundCategory.voice:
        return 'Voice Alerts';
      case SoundCategory.custom:
        return 'Custom Sounds';
    }
  }

  static IconData getCategoryIcon(SoundCategory category) {
    switch (category) {
      case SoundCategory.classic:
        return Icons.alarm;
      case SoundCategory.nature:
        return Icons.nature;
      case SoundCategory.music:
        return Icons.library_music;
      case SoundCategory.voice:
        return Icons.record_voice_over;
      case SoundCategory.custom:
        return Icons.folder_open;
    }
  }

  static Color getCategoryColor(SoundCategory category) {
    switch (category) {
      case SoundCategory.classic:
        return Colors.blue;
      case SoundCategory.nature:
        return Colors.green;
      case SoundCategory.music:
        return Colors.purple;
      case SoundCategory.voice:
        return Colors.orange;
      case SoundCategory.custom:
        return Colors.grey;
    }
  }
}
