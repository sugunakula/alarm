enum GameDifficulty {
  easy,
  medium,
  hard,
}

enum GameStatus {
  notStarted,
  playing,
  completed,
  failed,
}

class GameResult {
  final bool isSuccess;
  final int score;
  final Duration timeTaken;
  final int attempts;

  const GameResult({
    required this.isSuccess,
    required this.score,
    required this.timeTaken,
    required this.attempts,
  });
}

class GameStats {
  final int totalPlayed;
  final int totalCompleted;
  final int totalFailed;
  final Duration averageTime;
  final int bestScore;
  final DateTime lastPlayed;

  const GameStats({
    required this.totalPlayed,
    required this.totalCompleted,
    required this.totalFailed,
    required this.averageTime,
    required this.bestScore,
    required this.lastPlayed,
  });

  double get successRate {
    if (totalPlayed == 0) return 0.0;
    return totalCompleted / totalPlayed;
  }

  Map<String, dynamic> toJson() {
    return {
      'totalPlayed': totalPlayed,
      'totalCompleted': totalCompleted,
      'totalFailed': totalFailed,
      'averageTime': averageTime.inMilliseconds,
      'bestScore': bestScore,
      'lastPlayed': lastPlayed.millisecondsSinceEpoch,
    };
  }

  factory GameStats.fromJson(Map<String, dynamic> json) {
    return GameStats(
      totalPlayed: json['totalPlayed'] ?? 0,
      totalCompleted: json['totalCompleted'] ?? 0,
      totalFailed: json['totalFailed'] ?? 0,
      averageTime: Duration(milliseconds: json['averageTime'] ?? 0),
      bestScore: json['bestScore'] ?? 0,
      lastPlayed: DateTime.fromMillisecondsSinceEpoch(
        json['lastPlayed'] ?? DateTime.now().millisecondsSinceEpoch,
      ),
    );
  }

  GameStats copyWith({
    int? totalPlayed,
    int? totalCompleted,
    int? totalFailed,
    Duration? averageTime,
    int? bestScore,
    DateTime? lastPlayed,
  }) {
    return GameStats(
      totalPlayed: totalPlayed ?? this.totalPlayed,
      totalCompleted: totalCompleted ?? this.totalCompleted,
      totalFailed: totalFailed ?? this.totalFailed,
      averageTime: averageTime ?? this.averageTime,
      bestScore: bestScore ?? this.bestScore,
      lastPlayed: lastPlayed ?? this.lastPlayed,
    );
  }
}

class GameConfig {
  final GameDifficulty difficulty;
  final int timeLimit; // in seconds
  final int maxAttempts;
  final bool enableHints;
  final bool enableSound;

  const GameConfig({
    this.difficulty = GameDifficulty.easy,
    this.timeLimit = 60,
    this.maxAttempts = 3,
    this.enableHints = true,
    this.enableSound = true,
  });

  GameConfig copyWith({
    GameDifficulty? difficulty,
    int? timeLimit,
    int? maxAttempts,
    bool? enableHints,
    bool? enableSound,
  }) {
    return GameConfig(
      difficulty: difficulty ?? this.difficulty,
      timeLimit: timeLimit ?? this.timeLimit,
      maxAttempts: maxAttempts ?? this.maxAttempts,
      enableHints: enableHints ?? this.enableHints,
      enableSound: enableSound ?? this.enableSound,
    );
  }
}
