import 'package:flutter/material.dart';
import 'package:alarm/alarm.dart';
import 'package:system_alert_window/system_alert_window.dart';
import '../screens/alarm/alarm_dismissal_screen.dart';
import '../models/alarm_model.dart';
import '../providers/alarm_provider.dart';

class AlarmService {
  static final AlarmService _instance = AlarmService._internal();
  factory AlarmService() => _instance;
  AlarmService._internal();

  static BuildContext? _context;
  static bool _isAlarmScreenShown = false;

  static void initialize(BuildContext context) {
    _context = context;
    _setupAlarmListener();
  }

  static void _setupAlarmListener() {
    // Listen to alarm ring stream
    Alarm.ringStream.stream.listen((alarmSettings) {
      debugPrint('Alarm triggered: ID ${alarmSettings.id}');
      if (!_isAlarmScreenShown) {
        _showAlarmDismissalScreen(alarmSettings);
      }
    });
    
    // Also check for currently ringing alarms
    checkForRingingAlarms();
  }
  
  static void checkForRingingAlarms() {
    final ringingAlarms = Alarm.getAlarms();
    if (ringingAlarms.isNotEmpty && !_isAlarmScreenShown) {
      debugPrint('Found ringing alarm: ${ringingAlarms.first.id}');
      _showAlarmDismissalScreen(ringingAlarms.first);
    }
  }

  static Future<void> _showAlarmDismissalScreen(AlarmSettings alarmSettings) async {
    _isAlarmScreenShown = true;
    debugPrint('Attempting to show alarm dismissal screen for alarm ${alarmSettings.id}');
    
    try {
      // First try to show in app if context is available
      if (_context != null && _context!.mounted) {
        debugPrint('Showing dismissal screen within app');
        Navigator.of(_context!).pushAndRemoveUntil(
          MaterialPageRoute(
            builder: (context) => const AlarmDismissalScreen(),
            settings: const RouteSettings(name: '/alarm_dismissal'),
          ),
          (route) => false, // Remove all previous routes
        );
        return;
      }
      
      // If no context, try system overlay
      debugPrint('No app context, trying system overlay');
      await _requestOverlayPermissionAndShow(alarmSettings);
      
    } catch (e) {
      debugPrint('Error showing alarm dismissal screen: $e');
      // Final fallback: show overlay alert
      await _showOverlayAlert(alarmSettings);
    }
  }
  
  static Future<void> _requestOverlayPermissionAndShow(AlarmSettings alarmSettings) async {
    try {
      // Request system alert window permission
      bool hasPermission = await SystemAlertWindow.checkPermissions();
      if (!hasPermission) {
        debugPrint('Requesting overlay permission');
        await SystemAlertWindow.requestPermissions();
        hasPermission = await SystemAlertWindow.checkPermissions();
      }
      
      if (hasPermission) {
        await _showOverlayAlert(alarmSettings);
      } else {
        debugPrint('Overlay permission denied');
        // Try to launch app instead
        await _launchAppToForeground();
      }
    } catch (e) {
      debugPrint('Error with overlay: $e');
    }
  }
  
  static Future<void> _launchAppToForeground() async {
    // This would typically use a platform channel to bring app to foreground
    debugPrint('Would launch app to foreground here');
  }

  static Future<void> _showOverlayAlert(AlarmSettings alarmSettings) async {
    try {
      SystemAlarmWindow.showSystemWindow(
        height: 300,
        header: SystemWindowHeader(
          title: SystemWindowText(
            text: "WAKE UP!",
            fontSize: 18,
            textColor: Colors.white,
          ),
          padding: SystemWindowPadding.setSymmetricPadding(12, 12),
          decoration: SystemWindowDecoration(startColor: Colors.red),
        ),
        body: SystemWindowBody(
          rows: [
            EachRow(
              columns: [
                EachColumn(
                  text: SystemWindowText(
                    text: "Your alarm is ringing! Open the app to dismiss it with a mini-game.",
                    fontSize: 14,
                    textColor: Colors.black87,
                  ),
                ),
              ],
            ),
            EachRow(
              columns: [
                EachColumn(
                  text: SystemWindowText(
                    text: "Open App",
                    fontSize: 12,
                    textColor: Colors.white,
                  ),
                  padding: SystemWindowPadding.setSymmetricPadding(6, 8),
                  decoration: SystemWindowDecoration(startColor: Colors.blue),
                  onTap: () {
                    SystemAlertWindow.closeSystemWindow();
                    if (_context != null) {
                      Navigator.of(_context!).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => const AlarmDismissalScreen(),
                        ),
                        (route) => false,
                      );
                    }
                  },
                ),
              ],
            ),
          ],
        ),
        margin: SystemWindowMargin.fromLTRB(16, 16, 16, 16),
        gravity: SystemWindowGravity.TOP,
        notificationTitle: "NoSnooz Alarm",
        notificationBody: "Tap to dismiss alarm",
      );
    } catch (e) {
      debugPrint('Error showing overlay: $e');
    }
  }

  static void onAlarmDismissed() {
    _isAlarmScreenShown = false;
    SystemAlertWindow.closeSystemWindow();
  }

  static Future<void> requestSystemAlertPermission() async {
    try {
      bool hasPermission = await SystemAlertWindow.checkPermissions();
      if (!hasPermission) {
        await SystemAlertWindow.requestPermissions();
      }
    } catch (e) {
      debugPrint('Error requesting system alert permission: $e');
    }
  }
}
