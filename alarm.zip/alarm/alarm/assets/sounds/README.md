# Sound Assets

This folder should contain alarm sound files. Due to file size limitations, actual sound files are not included in this example.

## Required Sound Files:

### Classic Sounds (assets/sounds/classic/)
- classic_beep.mp3 - Default beeping alarm sound
- classic_bell.mp3 - Traditional bell sound
- classic_buzzer.mp3 - Sharp buzzer sound

### Nature Sounds (assets/sounds/nature/)
- birds_chirping.mp3 - Morning birds
- rain_drops.mp3 - Gentle rain sounds
- ocean_waves.mp3 - Ocean wave sounds

### Music Sounds (assets/sounds/music/)
- soft_piano.mp3 - Gentle piano melody
- guitar_strum.mp3 - Acoustic guitar
- electronic_beat.mp3 - Electronic music

### Voice Sounds (assets/sounds/voice/)
- wake_up_call.mp3 - Friendly "Wake up!" voice
- morning_greeting.mp3 - "Good morning!" voice

## Custom Sounds
Users can add their own sound files through the app's custom sound feature.

## Format Requirements:
- Format: MP3 or WAV
- Duration: 10-30 seconds recommended
- Quality: 128kbps or higher for MP3
- Loop: Should loop seamlessly if possible
