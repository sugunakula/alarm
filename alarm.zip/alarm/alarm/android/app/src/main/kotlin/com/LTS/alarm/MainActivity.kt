package com.LTS.alarm

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
