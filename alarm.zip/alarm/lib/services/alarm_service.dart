import 'dart:async';
import 'package:flutter/material.dart';
import 'package:alarm/alarm.dart';
import 'package:system_alert_window/system_alert_window.dart';
import '../screens/alarm/alarm_dismissal_screen.dart';

class AlarmService {
  static final AlarmService _instance = AlarmService._internal();
  factory AlarmService() => _instance;
  AlarmService._internal();

  static BuildContext? _context;
  static bool _isAlarmScreenShown = false;
  static StreamSubscription<AlarmSettings>? _subscription;

  static void initialize(BuildContext context) {
    _context = context;
    Alarm.init(); // Must initialize alarm
    _subscription ??= Alarm.ringStream.stream.listen((settings) {
      debugPrint('Alarm fired: id=${settings.id}');
      if (!_isAlarmScreenShown) _showScreen(settings);
    });
    checkForRingingAlarms();
  }

  static Future<void> checkForRingingAlarms() async {
    final list = await Alarm.getAlarms();
    if (list.isNotEmpty && !_isAlarmScreenShown) {
      _showScreen(list.first);
    }
  }

  static Future<void> _showScreen(AlarmSettings settings) async {
    _isAlarmScreenShown = true;
    try {
      if (_context != null && _context!.mounted) {
        Navigator.of(_context!).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const AlarmDismissalScreen()),
                (_) => false);
      } else {
        await _requestOverlay(settings);
      }
    } catch (e) {
      debugPrint('Error showing UI: $e');
      await _showOverlay(settings);
    }
  }

  static Future<void> _requestOverlay(AlarmSettings settings) async {
    bool has = await SystemAlertWindow.checkPermissions() ?? false;
    if (!has) await SystemAlertWindow.requestPermissions();
    has = await SystemAlertWindow.checkPermissions() ?? false;
    if (has) {
      await _showOverlay(settings);
    } else {
      debugPrint('Overlay denied, launching app foreground');
      await _launchApp();
    }
  }

  static Future<void> _showOverlay(AlarmSettings settings) async {
    await SystemAlertWindow.showSystemWindow(
      gravity: SystemWindowGravity.CENTER,
      notificationTitle: 'Alarm ringing',
      notificationBody: 'Tap to dismiss',
      prefMode: SystemWindowPrefMode.OVERLAY,
    );

    SystemAlertWindow.overlayListener.listen((tag) {
      if (tag == 'dismiss') {
        onAlarmDismissed();
      }
    });
  }

  static Future<void> _launchApp() async {
    debugPrint('Would launch main app via platform channel');
  }

  static void onAlarmDismissed() {
    _isAlarmScreenShown = false;
    SystemAlertWindow.closeSystemWindow();
  }

  static Future<void> dispose() async {
    await _subscription?.cancel();
  }

  static Future<void> requestSystemAlertPermission() async {
    bool has = await SystemAlertWindow.checkPermissions() ?? false;
    if (!has) {
      await SystemAlertWindow.requestPermissions();
    }
  }

}
