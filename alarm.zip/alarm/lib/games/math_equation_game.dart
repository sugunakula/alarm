import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_model.dart';

class MathEquationGame extends StatefulWidget {
  final GameConfig? config;
  final Function(GameResult)? onGameComplete;
  final Function(bool, int)? onGameResult; // For alarm mode
  final bool isPracticeMode;

  const MathEquationGame({
    super.key,
    this.config,
    this.onGameComplete,
    this.onGameResult,
    this.isPracticeMode = false,
  });

  @override
  State<MathEquationGame> createState() => _MathEquationGameState();
}

class _MathEquationGameState extends State<MathEquationGame>
    with TickerProviderStateMixin {
  late AnimationController _timerController;
  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  String _question = '';
  int _correctAnswer = 0;
  List<int> _options = [];
  int? _selectedAnswer;
  int _currentScore = 0;
  int _questionsAnswered = 0;
  int _wrongAttempts = 0;
  DateTime? _startTime;
  bool _isGameComplete = false;

  final int _totalQuestions = 5;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _startGame();
  }

  void _initializeAnimations() {
    final timeLimit = widget.config?.timeLimit ?? 60; // Default 60 seconds for practice mode
    _timerController = AnimationController(
      duration: Duration(seconds: timeLimit),
      vsync: this,
    );

    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _shakeAnimation = Tween<double>(
      begin: 0,
      end: 10,
    ).animate(CurvedAnimation(
      parent: _shakeController,
      curve: Curves.elasticInOut,
    ));

    _timerController.addListener(() {
      if (_timerController.isCompleted && !_isGameComplete) {
        _endGame(false);
      }
    });

    _timerController.forward();
  }

  void _startGame() {
    _startTime = DateTime.now();
    _generateQuestion();
  }

  void _generateQuestion() {
    final random = Random();
    int num1, num2, result;
    String operation;

    switch (widget.config?.difficulty ?? GameDifficulty.medium) {
      case GameDifficulty.easy:
        // Single digit addition/subtraction
        num1 = random.nextInt(10) + 1;
        num2 = random.nextInt(10) + 1;
        if (random.nextBool()) {
          operation = '+';
          result = num1 + num2;
        } else {
          operation = '-';
          if (num1 < num2) {
            final temp = num1;
            num1 = num2;
            num2 = temp;
          }
          result = num1 - num2;
        }
        break;

      case GameDifficulty.medium:
        // Two digit numbers, addition/subtraction/multiplication
        final operationType = random.nextInt(3);
        if (operationType == 0) {
          // Addition
          num1 = random.nextInt(50) + 10;
          num2 = random.nextInt(50) + 10;
          operation = '+';
          result = num1 + num2;
        } else if (operationType == 1) {
          // Subtraction
          num1 = random.nextInt(50) + 50;
          num2 = random.nextInt(50) + 10;
          operation = '-';
          result = num1 - num2;
        } else {
          // Multiplication (single digits)
          num1 = random.nextInt(9) + 2;
          num2 = random.nextInt(9) + 2;
          operation = '×';
          result = num1 * num2;
        }
        break;

      case GameDifficulty.hard:
        // More complex operations
        final operationType = random.nextInt(4);
        if (operationType == 0) {
          // Large addition
          num1 = random.nextInt(500) + 100;
          num2 = random.nextInt(500) + 100;
          operation = '+';
          result = num1 + num2;
        } else if (operationType == 1) {
          // Large subtraction
          num1 = random.nextInt(500) + 500;
          num2 = random.nextInt(500) + 100;
          operation = '-';
          result = num1 - num2;
        } else if (operationType == 2) {
          // Two digit multiplication
          num1 = random.nextInt(20) + 10;
          num2 = random.nextInt(20) + 10;
          operation = '×';
          result = num1 * num2;
        } else {
          // Division
          result = random.nextInt(20) + 2;
          num2 = random.nextInt(10) + 2;
          num1 = result * num2;
          operation = '÷';
        }
        break;
    }

    _question = '$num1 $operation $num2 = ?';
    _correctAnswer = result;
    _generateOptions(result);
    _selectedAnswer = null;

    setState(() {});
  }

  void _generateOptions(int correctAnswer) {
    final random = Random();
    final options = <int>{correctAnswer};

    while (options.length < 4) {
      int wrongAnswer;
      final variation = random.nextInt(20) + 1;
      
      if (random.nextBool()) {
        wrongAnswer = correctAnswer + variation;
      } else {
        wrongAnswer = correctAnswer - variation;
      }
      
      if (wrongAnswer > 0) {
        options.add(wrongAnswer);
      }
    }

    _options = options.toList()..shuffle();
  }

  void _selectAnswer(int answer) {
    if (_isGameComplete) return;

    setState(() {
      _selectedAnswer = answer;
    });

    // Delay to show selection
    Future.delayed(const Duration(milliseconds: 500), () {
      if (answer == _correctAnswer) {
        _handleCorrectAnswer();
      } else {
        _handleWrongAnswer();
      }
    });
  }

  void _handleCorrectAnswer() {
    _currentScore += _getScoreForQuestion();
    _questionsAnswered++;

    if (_questionsAnswered >= _totalQuestions) {
      _endGame(true);
    } else {
      _generateQuestion();
    }
  }

  void _handleWrongAnswer() {
    _wrongAttempts++;
    _shakeController.forward().then((_) => _shakeController.reset());
    
    if (_wrongAttempts >= (widget.config?.maxAttempts ?? 3)) {
      _endGame(false);
    } else {
      // Show hint if enabled
      if (widget.config?.enableHints ?? false) {
        _showHint();
      }
      // Generate new question after wrong answer
      Future.delayed(const Duration(milliseconds: 1000), () {
        if (!_isGameComplete) {
          _generateQuestion();
        }
      });
    }
  }

  void _showHint() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Hint: The answer is close to $_correctAnswer'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.orange,
      ),
    );
  }

  int _getScoreForQuestion() {
    // Base score modified by difficulty and remaining time
    int baseScore = (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.easy 
        ? 10 
        : (widget.config?.difficulty ?? GameDifficulty.medium) == GameDifficulty.medium 
            ? 20 
            : 30;
    
    // Bonus for remaining time
    final timeLimit = widget.config?.timeLimit ?? 60;
    final remainingTime = timeLimit - _timerController.value * timeLimit;
    final timeBonus = (remainingTime / timeLimit * 10).round();
    
    return baseScore + timeBonus;
  }

  void _endGame(bool success) {
    if (_isGameComplete) return;
    
    _isGameComplete = true;
    _timerController.stop();

    final timeTaken = _startTime != null 
        ? DateTime.now().difference(_startTime!) 
        : Duration.zero;

    final result = GameResult(
      isSuccess: success,
      score: _currentScore,
      timeTaken: timeTaken,
      attempts: _wrongAttempts + 1,
    );

    widget.onGameComplete?.call(result);
  }

  @override
  void dispose() {
    _timerController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Math Challenge'),
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Text(
                'Score: $_currentScore',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: AnimatedBuilder(
        animation: _shakeAnimation,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(_shakeAnimation.value, 0),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Progress indicators
                  Row(
                    children: [
                      Expanded(
                        child: LinearProgressIndicator(
                          value: _timerController.value,
                          backgroundColor: Colors.grey[300],
                          valueColor: AlwaysStoppedAnimation<Color>(
                            _timerController.value > 0.7 
                                ? Colors.red 
                                : Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Text('${_questionsAnswered + 1}/$_totalQuestions'),
                    ],
                  ),
                  
                  const SizedBox(height: 32),
                  
                  // Question
                  Card(
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        _question,
                        style: Theme.of(context).textTheme.displaySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                  
                  // Answer options
                  Expanded(
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                      ),
                      itemCount: _options.length,
                      itemBuilder: (context, index) {
                        final option = _options[index];
                        final isSelected = _selectedAnswer == option;
                        final isCorrect = option == _correctAnswer;
                        
                        Color? backgroundColor;
                        Color? textColor;
                        
                        if (isSelected) {
                          if (isCorrect) {
                            backgroundColor = Colors.green;
                            textColor = Colors.white;
                          } else {
                            backgroundColor = Colors.red;
                            textColor = Colors.white;
                          }
                        }
                        
                        return ElevatedButton(
                          onPressed: _selectedAnswer == null 
                              ? () => _selectAnswer(option)
                              : null,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: backgroundColor,
                            foregroundColor: textColor,
                            elevation: isSelected ? 8 : 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          child: Text(
                            option.toString(),
                            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: textColor,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  
                  // Attempts remaining
                  if (_wrongAttempts > 0) ...[
                    const SizedBox(height: 16),
                    Text(
                      'Wrong attempts: $_wrongAttempts/${widget.config?.maxAttempts ?? 3}',
                      style: TextStyle(
                        color: Colors.red[700],
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
  

  

  
  void _completeGame(bool success) {
    if (_isGameComplete) return;
    
    setState(() {
      _isGameComplete = true;
    });
    
    _timerController.stop();
    
    final endTime = DateTime.now();
    final timeTaken = _startTime != null ? endTime.difference(_startTime!).inSeconds : 0;
    
    if (widget.isPracticeMode) {
      // Show result dialog for practice mode
      _showResultDialog(success);
    } else {
      // For alarm mode, call the appropriate callback
      if (widget.onGameResult != null) {
        widget.onGameResult!(success, _currentScore);
      } else if (widget.onGameComplete != null) {
        final result = GameResult(
          isSuccess: success,
          score: _currentScore,
          timeTaken: Duration(seconds: timeTaken),
          attempts: _wrongAttempts + 1,
        );
        widget.onGameComplete?.call(result);
      }
    }
  }
  
  void _showResultDialog(bool success) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text(success ? 'Great Job!' : 'Try Again!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              success ? Icons.check_circle : Icons.cancel,
              size: 64,
              color: success ? Colors.green : Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              success 
                  ? 'You solved $_questionsAnswered out of $_totalQuestions problems!'
                  : 'Keep practicing to improve your math skills!',
            ),
            const SizedBox(height: 8),
            Text('Score: $_currentScore'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(); // Close game screen
            },
            child: const Text('Done'),
          ),
          if (!success)
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close dialog
                // Reset game
                setState(() {
                  _currentScore = 0;
                  _questionsAnswered = 0;
                  _wrongAttempts = 0;
                  _isGameComplete = false;
                  _selectedAnswer = null;
                });
                _startGame();
              },
              child: const Text('Try Again'),
            ),
        ],
      ),
    );
  }
}
