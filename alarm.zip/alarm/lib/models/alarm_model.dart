import 'package:alarm/alarm.dart';
import 'sound_model.dart';

enum RepeatOption {
  never,
  daily,
  weekdays,
  weekends,
  custom,
}

enum GameType {
  mathEquation,
  findTheBall,
  puzzleSolve,
  colorMatchBlitz,
  memoryFlip,
}

class AlarmModel {
  final int id;
  final String label;
  final DateTime dateTime;
  final RepeatOption repeatOption;
  final List<int> customDays; // 1-7 for Monday-Sunday
  final bool isEnabled;
  final GameType gameType;
  final String soundId;
  final bool vibrate;
  final bool enableLight;

  AlarmModel({
    required this.id,
    required this.label,
    required this.dateTime,
    this.repeatOption = RepeatOption.never,
    this.customDays = const [],
    this.isEnabled = true,
    this.gameType = GameType.mathEquation,
    this.soundId = 'classic_beep',
    this.vibrate = true,
    this.enableLight = true,
  });

  AlarmSettings toAlarmSettings() {
    final sound = SoundManager.getSoundById(soundId) ?? SoundManager.defaultSound;
    return AlarmSettings(
      id: id,
      dateTime: dateTime,
      assetAudioPath: sound.assetPath,
      loopAudio: true,
      vibrate: vibrate,
      volume: 0.8,
      fadeDuration: 3.0,
      notificationTitle: 'NoSnooz Alarm',
      notificationBody: label,
      enableNotificationOnKill: true,
    );
  }

  AlarmModel copyWith({
    int? id,
    String? label,
    DateTime? dateTime,
    RepeatOption? repeatOption,
    List<int>? customDays,
    bool? isEnabled,
    GameType? gameType,
    String? soundId,
    bool? vibrate,
    bool? enableLight,
  }) {
    return AlarmModel(
      id: id ?? this.id,
      label: label ?? this.label,
      dateTime: dateTime ?? this.dateTime,
      repeatOption: repeatOption ?? this.repeatOption,
      customDays: customDays ?? this.customDays,
      isEnabled: isEnabled ?? this.isEnabled,
      gameType: gameType ?? this.gameType,
      soundId: soundId ?? this.soundId,
      vibrate: vibrate ?? this.vibrate,
      enableLight: enableLight ?? this.enableLight,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'label': label,
      'dateTime': dateTime.millisecondsSinceEpoch,
      'repeatOption': repeatOption.index,
      'customDays': customDays,
      'isEnabled': isEnabled,
      'gameType': gameType.index,
      'soundId': soundId,
      'vibrate': vibrate,
      'enableLight': enableLight,
    };
  }

  factory AlarmModel.fromJson(Map<String, dynamic> json) {
    return AlarmModel(
      id: json['id'],
      label: json['label'],
      dateTime: DateTime.fromMillisecondsSinceEpoch(json['dateTime']),
      repeatOption: RepeatOption.values[json['repeatOption']],
      customDays: List<int>.from(json['customDays']),
      isEnabled: json['isEnabled'],
      gameType: GameType.values[json['gameType']],
      soundId: json['soundId'] ?? 'classic_beep',
      vibrate: json['vibrate'],
      enableLight: json['enableLight'],
    );
  }

  bool shouldAlarmRingToday() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final alarmDate = DateTime(dateTime.year, dateTime.month, dateTime.day);
    
    if (alarmDate.isBefore(today)) {
      return false;
    }
    
    switch (repeatOption) {
      case RepeatOption.never:
        return alarmDate == today;
      case RepeatOption.daily:
        return true;
      case RepeatOption.weekdays:
        final weekday = now.weekday;
        return weekday >= 1 && weekday <= 5; // Monday to Friday
      case RepeatOption.weekends:
        final weekday = now.weekday;
        return weekday == 6 || weekday == 7; // Saturday and Sunday
      case RepeatOption.custom:
        return customDays.contains(now.weekday);
    }
  }

  DateTime? getNextAlarmTime() {
    final now = DateTime.now();
    
    switch (repeatOption) {
      case RepeatOption.never:
        return dateTime.isAfter(now) ? dateTime : null;
      case RepeatOption.daily:
        var nextAlarm = DateTime(now.year, now.month, now.day, dateTime.hour, dateTime.minute);
        if (nextAlarm.isBefore(now) || nextAlarm == now) {
          nextAlarm = nextAlarm.add(const Duration(days: 1));
        }
        return nextAlarm;
      case RepeatOption.weekdays:
      case RepeatOption.weekends:
      case RepeatOption.custom:
        var nextAlarm = DateTime(now.year, now.month, now.day, dateTime.hour, dateTime.minute);
        
        for (int i = 0; i < 7; i++) {
          if (shouldAlarmRingToday() && (nextAlarm.isAfter(now))) {
            return nextAlarm;
          }
          nextAlarm = nextAlarm.add(const Duration(days: 1));
        }
        return nextAlarm;
    }
  }
}
